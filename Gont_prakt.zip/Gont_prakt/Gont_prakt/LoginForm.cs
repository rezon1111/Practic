﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Gont_prakt
{
    public class LoginForm : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnRegister;
        private Button btnExit;
        private Label lblError;
        private Panel leftPanel;
        private Panel rightPanel;

        public LoginForm()
        {
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.White;

            CreateModernDesign();
        }

        private void CreateModernDesign()
        {
            // Левая панель - градиентный фон
            leftPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 450,
                BackColor = Color.FromArgb(41, 128, 185)
            };

            // Рисуем градиент на левой панели
            leftPanel.Paint += (s, e) =>
            {
                Rectangle rect = new Rectangle(0, 0, leftPanel.Width, leftPanel.Height);
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    rect,
                    Color.FromArgb(52, 152, 219),
                    Color.FromArgb(41, 128, 185),
                    LinearGradientMode.Vertical))
                {
                    e.Graphics.FillRectangle(brush, rect);
                }

                // Рисуем логотип
                using (Font font = new Font("Segoe UI", 48, FontStyle.Bold))
                {
                    string text = "КХЗ";
                    SizeF textSize = e.Graphics.MeasureString(text, font);
                    PointF textPoint = new PointF(
                        (leftPanel.Width - textSize.Width) / 2,
                        150
                    );

                    // Тень
                    e.Graphics.DrawString(text, font, Brushes.Black,
                        textPoint.X + 3, textPoint.Y + 3);

                    // Основной текст
                    using (Brush textBrush = new SolidBrush(Color.FromArgb(255, 255, 255)))
                    {
                        e.Graphics.DrawString(text, font, textBrush, textPoint);
                    }
                }

                // Подпись
                using (Font font = new Font("Segoe UI", 14, FontStyle.Regular))
                {
                    string text = "Система контроля качества";
                    SizeF textSize = e.Graphics.MeasureString(text, font);
                    PointF textPoint = new PointF(
                        (leftPanel.Width - textSize.Width) / 2,
                        250
                    );

                    e.Graphics.DrawString(text, font, Brushes.WhiteSmoke, textPoint);
                }
            };

            // Правая панель - форма входа
            rightPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(50)
            };

            // Заголовок
            Label lblWelcome = new Label
            {
                Text = "Добро пожаловать!",
                Font = new Font("Segoe UI", 28, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 73, 94),
                Location = new Point(50, 60),
                Size = new Size(450, 50),
                TextAlign = ContentAlignment.MiddleLeft
            };

            Label lblSubWelcome = new Label
            {
                Text = "Войдите в систему для продолжения",
                Font = new Font("Segoe UI", 14),
                ForeColor = Color.FromArgb(127, 140, 141),
                Location = new Point(50, 110),
                Size = new Size(450, 30),
                TextAlign = ContentAlignment.MiddleLeft
            };

            // Иконка пользователя
            Label lblUserIcon = new Label
            {
                Text = "👤",
                Font = new Font("Segoe UI", 18),
                Location = new Point(50, 170),
                Size = new Size(40, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Поле логина
            Panel usernamePanel = new Panel
            {
                Location = new Point(90, 170),
                Size = new Size(350, 45),
                BackColor = Color.FromArgb(245, 245, 245)
            };

            txtUsername = new TextBox
            {
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 12),
                Location = new Point(15, 12),
                Size = new Size(320, 22),
                BackColor = Color.FromArgb(245, 245, 245)
            };

            Label lblUsernamePlaceholder = new Label
            {
                Text = "Имя пользователя",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.Gray,
                Location = new Point(15, 12),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            txtUsername.GotFocus += (s, e) => lblUsernamePlaceholder.Visible = false;
            txtUsername.LostFocus += (s, e) => lblUsernamePlaceholder.Visible = string.IsNullOrEmpty(txtUsername.Text);
            usernamePanel.Controls.Add(txtUsername);
            usernamePanel.Controls.Add(lblUsernamePlaceholder);

            // Иконка пароля
            Label lblPassIcon = new Label
            {
                Text = "🔒",
                Font = new Font("Segoe UI", 18),
                Location = new Point(50, 230),
                Size = new Size(40, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Поле пароля
            Panel passwordPanel = new Panel
            {
                Location = new Point(90, 230),
                Size = new Size(350, 45),
                BackColor = Color.FromArgb(245, 245, 245)
            };

            txtPassword = new TextBox
            {
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 12),
                Location = new Point(15, 12),
                Size = new Size(320, 22),
                BackColor = Color.FromArgb(245, 245, 245),
                PasswordChar = '●',
                UseSystemPasswordChar = true
            };

            Label lblPasswordPlaceholder = new Label
            {
                Text = "Пароль",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.Gray,
                Location = new Point(15, 12),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            txtPassword.GotFocus += (s, e) => lblPasswordPlaceholder.Visible = false;
            txtPassword.LostFocus += (s, e) => lblPasswordPlaceholder.Visible = string.IsNullOrEmpty(txtPassword.Text);
            passwordPanel.Controls.Add(txtPassword);
            passwordPanel.Controls.Add(lblPasswordPlaceholder);

            // Сообщение об ошибке
            lblError = new Label
            {
                Location = new Point(50, 290),
                Size = new Size(390, 30),
                ForeColor = Color.FromArgb(231, 76, 60),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Visible = false,
                BackColor = Color.FromArgb(255, 235, 235)
            };

            // КНОПКА ВХОДА - ТЕПЕРЬ С НАДПИСЬЮ!
            btnLogin = new Button
            {
                Text = "ВОЙТИ В СИСТЕМУ",
                Location = new Point(50, 340),
                Size = new Size(390, 55),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.White,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btnLogin.FlatAppearance.BorderSize = 0;

            // Градиент для кнопки
            btnLogin.Paint += (s, e) =>
            {
                Rectangle rect = new Rectangle(0, 0, btnLogin.Width, btnLogin.Height);
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    rect,
                    Color.FromArgb(52, 152, 219),
                    Color.FromArgb(41, 128, 185),
                    LinearGradientMode.Horizontal))
                {
                    e.Graphics.FillRectangle(brush, rect);
                }

                // Рисуем текст поверх градиента
                TextRenderer.DrawText(e.Graphics, btnLogin.Text, btnLogin.Font,
                    rect, Color.White,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            };
            btnLogin.Click += BtnLogin_Click;

            // Панель для дополнительных кнопок
            Panel bottomPanel = new Panel
            {
                Location = new Point(50, 420),
                Size = new Size(390, 80),
                BackColor = Color.White
            };

            // Кнопка регистрации
            btnRegister = new Button
            {
                Text = "📝  Регистрация",
                Location = new Point(0, 20),
                Size = new Size(180, 45),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 152, 219),
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10, 0, 0, 0)
            };
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.FlatAppearance.MouseOverBackColor = Color.FromArgb(240, 248, 255);
            btnRegister.Click += BtnRegister_Click;

            // Кнопка выхода
            btnExit = new Button
            {
                Text = "🚪  Выход",
                Location = new Point(210, 20),
                Size = new Size(180, 45),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.FromArgb(127, 140, 141),
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10, 0, 0, 0)
            };
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatAppearance.MouseOverBackColor = Color.FromArgb(245, 245, 245);
            btnExit.Click += BtnExit_Click;

            // Разделительная линия
            Panel line = new Panel
            {
                Location = new Point(0, 15),
                Size = new Size(390, 1),
                BackColor = Color.FromArgb(230, 230, 230)
            };

            bottomPanel.Controls.Add(line);
            bottomPanel.Controls.Add(btnRegister);
            bottomPanel.Controls.Add(btnExit);

            // Добавляем все на правую панель
            rightPanel.Controls.Add(lblWelcome);
            rightPanel.Controls.Add(lblSubWelcome);
            rightPanel.Controls.Add(lblUserIcon);
            rightPanel.Controls.Add(usernamePanel);
            rightPanel.Controls.Add(lblPassIcon);
            rightPanel.Controls.Add(passwordPanel);
            rightPanel.Controls.Add(lblError);
            rightPanel.Controls.Add(btnLogin);
            rightPanel.Controls.Add(bottomPanel);

            // Добавляем панели на форму
            this.Controls.Add(rightPanel);
            this.Controls.Add(leftPanel);

            // Возможность перетаскивать окно
            this.MouseDown += (s, e) => {
                if (e.Button == MouseButtons.Left)
                {
                    this.Capture = false;
                    Message m = Message.Create(this.Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                    this.WndProc(ref m);
                }
            };
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль!");
                return;
            }

            string hashedPassword = DatabaseHelper.HashPassword(password);

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT UserID, Username, FullName, Role, Email, IsActive 
                                   FROM Users WHERE Username = @username 
                                   AND PasswordHash = @password";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", hashedPassword);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                if (!reader.GetBoolean(5))
                                {
                                    ShowError("Пользователь заблокирован!");
                                    return;
                                }

                                User currentUser = new User
                                {
                                    UserID = reader.GetInt32(0),
                                    Username = reader.GetString(1),
                                    FullName = reader.IsDBNull(2) ? "" : reader.GetString(2),
                                    Role = reader.GetString(3),
                                    Email = reader.IsDBNull(4) ? "" : reader.GetString(4)
                                };

                                this.Hide();
                                MainForm mainForm = new MainForm(currentUser);
                                mainForm.ShowDialog();
                                this.Close();
                            }
                            else
                            {
                                ShowError("Неверный логин или пароль!");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка: {ex.Message}");
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowError(string message)
        {
            lblError.Text = "⚠  " + message;
            lblError.Visible = true;

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 3000;
            timer.Tick += (s, args) => {
                lblError.Visible = false;
                timer.Stop();
            };
            timer.Start();
        }
    }
}