﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class UserEditForm : Form
    {
        private int? userId;
        private TextBox txtUsername;
        private TextBox txtFullName;
        private TextBox txtEmail;
        private TextBox txtPassword;
        private TextBox txtConfirmPassword;
        private ComboBox cmbRole;
        private CheckBox chkIsActive;
        private Button btnSave;
        private Button btnCancel;
        private Label lblTitle;

        public UserEditForm(int? id = null)
        {
            InitializeComponent();
            userId = id;

            if (userId.HasValue)
            {
                lblTitle.Text = "Редактирование пользователя";
                LoadUserData();
            }
            else
            {
                lblTitle.Text = "Добавление пользователя";
                chkIsActive.Checked = true;
                cmbRole.SelectedIndex = 1; // Client по умолчанию
            }
        }

        private void InitializeComponent()
        {
            this.Text = userId.HasValue ? "Редактирование пользователя" : "Новый пользователь";
            this.Size = new Size(450, 500);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.FromArgb(240, 240, 241);

            // Основная панель
            Panel mainPanel = new Panel
            {
                Location = new Point(20, 20),
                Size = new Size(400, 420),
                BackColor = Color.White,
                Padding = new Padding(15)
            };

            lblTitle = new Label
            {
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 73, 94),
                Location = new Point(15, 10),
                AutoSize = true
            };

            // Логин
            Label lblUsername = new Label
            {
                Text = "Логин:*",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 50),
                AutoSize = true
            };

            txtUsername = new TextBox
            {
                Location = new Point(15, 75),
                Size = new Size(350, 25),
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle
            };

            // ФИО
            Label lblFullName = new Label
            {
                Text = "ФИО:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 110),
                AutoSize = true
            };

            txtFullName = new TextBox
            {
                Location = new Point(15, 135),
                Size = new Size(350, 25),
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Email
            Label lblEmail = new Label
            {
                Text = "Email:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 170),
                AutoSize = true
            };

            txtEmail = new TextBox
            {
                Location = new Point(15, 195),
                Size = new Size(350, 25),
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Пароль (только для нового пользователя)
            if (!userId.HasValue)
            {
                Label lblPassword = new Label
                {
                    Text = "Пароль:*",
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Location = new Point(15, 230),
                    AutoSize = true
                };

                txtPassword = new TextBox
                {
                    Location = new Point(15, 255),
                    Size = new Size(350, 25),
                    Font = new Font("Segoe UI", 10),
                    BorderStyle = BorderStyle.FixedSingle,
                    PasswordChar = '●',
                    UseSystemPasswordChar = true
                };

                Label lblConfirmPassword = new Label
                {
                    Text = "Подтвердите пароль:*",
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Location = new Point(15, 290),
                    AutoSize = true
                };

                txtConfirmPassword = new TextBox
                {
                    Location = new Point(15, 315),
                    Size = new Size(350, 25),
                    Font = new Font("Segoe UI", 10),
                    BorderStyle = BorderStyle.FixedSingle,
                    PasswordChar = '●',
                    UseSystemPasswordChar = true
                };

                mainPanel.Controls.Add(lblPassword);
                mainPanel.Controls.Add(txtPassword);
                mainPanel.Controls.Add(lblConfirmPassword);
                mainPanel.Controls.Add(txtConfirmPassword);
            }

            // Роль
            Label lblRole = new Label
            {
                Text = "Роль:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, userId.HasValue ? 230 : 350),
                AutoSize = true
            };

            cmbRole = new ComboBox
            {
                Location = new Point(15, userId.HasValue ? 255 : 375),
                Size = new Size(150, 25),
                Font = new Font("Segoe UI", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbRole.Items.AddRange(new object[] { "Admin", "Client" });

            // Активен
            chkIsActive = new CheckBox
            {
                Text = "Активен",
                Location = new Point(180, userId.HasValue ? 255 : 375),
                Font = new Font("Segoe UI", 10),
                Checked = true
            };

            // Панель кнопок
            Panel buttonPanel = new Panel
            {
                Location = new Point(15, 440),
                Size = new Size(350, 50),
                BackColor = Color.FromArgb(236, 240, 241)
            };

            btnSave = new Button
            {
                Text = "Сохранить",
                Location = new Point(50, 10),
                Size = new Size(100, 30),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button
            {
                Text = "Отмена",
                Location = new Point(200, 10),
                Size = new Size(100, 30),
                BackColor = Color.FromArgb(149, 165, 166),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnCancel.Click += (s, e) => this.Close();

            buttonPanel.Controls.Add(btnSave);
            buttonPanel.Controls.Add(btnCancel);

            mainPanel.Controls.Add(lblTitle);
            mainPanel.Controls.Add(lblUsername);
            mainPanel.Controls.Add(txtUsername);
            mainPanel.Controls.Add(lblFullName);
            mainPanel.Controls.Add(txtFullName);
            mainPanel.Controls.Add(lblEmail);
            mainPanel.Controls.Add(txtEmail);
            mainPanel.Controls.Add(lblRole);
            mainPanel.Controls.Add(cmbRole);
            mainPanel.Controls.Add(chkIsActive);
            mainPanel.Controls.Add(buttonPanel);

            this.Controls.Add(mainPanel);
        }

        private void LoadUserData()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT Username, FullName, Email, Role, IsActive 
                                   FROM Users WHERE UserID = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", userId.Value);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtUsername.Text = reader["Username"].ToString();
                                txtFullName.Text = reader["FullName"].ToString();
                                txtEmail.Text = reader["Email"].ToString();
                                cmbRole.SelectedItem = reader["Role"].ToString();
                                chkIsActive.Checked = Convert.ToBoolean(reader["IsActive"]);

                                txtUsername.Enabled = false; // Нельзя менять логин
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Введите логин!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (txtUsername.Text.Length < 3)
            {
                MessageBox.Show("Логин должен содержать минимум 3 символа!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!userId.HasValue)
            {
                if (string.IsNullOrWhiteSpace(txtPassword.Text))
                {
                    MessageBox.Show("Введите пароль!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (txtPassword.Text.Length < 4)
                {
                    MessageBox.Show("Пароль должен содержать минимум 4 символа!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (txtPassword.Text != txtConfirmPassword.Text)
                {
                    MessageBox.Show("Пароли не совпадают!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                try
                {
                    var addr = new System.Net.Mail.MailAddress(txtEmail.Text);
                }
                catch
                {
                    MessageBox.Show("Введите корректный email!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    if (userId.HasValue)
                    {
                        // Обновление
                        string query = @"UPDATE Users 
                                       SET FullName = @fullname, Email = @email, 
                                           Role = @role, IsActive = @active
                                       WHERE UserID = @id";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@fullname", string.IsNullOrWhiteSpace(txtFullName.Text) ? DBNull.Value : (object)txtFullName.Text);
                            cmd.Parameters.AddWithValue("@email", string.IsNullOrWhiteSpace(txtEmail.Text) ? DBNull.Value : (object)txtEmail.Text);
                            cmd.Parameters.AddWithValue("@role", cmbRole.SelectedItem.ToString());
                            cmd.Parameters.AddWithValue("@active", chkIsActive.Checked);
                            cmd.Parameters.AddWithValue("@id", userId.Value);

                            cmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // Проверка уникальности логина
                        string checkQuery = "SELECT COUNT(*) FROM Users WHERE Username = @username";
                        using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                        {
                            checkCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                            int count = (int)checkCmd.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("Пользователь с таким логином уже существует!", "Ошибка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

                        // Добавление
                        string query = @"INSERT INTO Users (Username, PasswordHash, FullName, Email, Role, IsActive)
                                       VALUES (@username, @password, @fullname, @email, @role, @active)";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                            cmd.Parameters.AddWithValue("@password", DatabaseHelper.HashPassword(txtPassword.Text));
                            cmd.Parameters.AddWithValue("@fullname", string.IsNullOrWhiteSpace(txtFullName.Text) ? DBNull.Value : (object)txtFullName.Text);
                            cmd.Parameters.AddWithValue("@email", string.IsNullOrWhiteSpace(txtEmail.Text) ? DBNull.Value : (object)txtEmail.Text);
                            cmd.Parameters.AddWithValue("@role", cmbRole.SelectedItem.ToString());
                            cmd.Parameters.AddWithValue("@active", chkIsActive.Checked);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}