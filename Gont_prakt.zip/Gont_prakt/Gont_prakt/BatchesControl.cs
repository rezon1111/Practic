﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Gont_prakt
{
    public class BatchesControl : UserControl
    {
        private User currentUser;
        private DataGridView dgvBatches;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private TextBox txtSearch;
        private ComboBox cmbStatus;
        private Label lblTotal;
        private FlowLayoutPanel panel1;
        private FlowLayoutPanel panel2;

        public BatchesControl(User user)
        {
            currentUser = user;
            InitializeControls();
            LoadBatches();
        }

        private void InitializeControls()
        {
            this.Dock = DockStyle.Fill;
            this.BackColor = Color.White;
            this.Padding = new Padding(10);

            // ВЕРХНЯЯ ПАНЕЛЬ С ЗАГОЛОВКОМ
            Label lblTitle = new Label
            {
                Text = "Партии продукции",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.Black,
                Location = new Point(10, 10),
                AutoSize = true
            };

            lblTotal = new Label
            {
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                Location = new Point(200, 18),
                AutoSize = true,
                Text = "Всего: 0"
            };

            // ПАНЕЛЬ 1 - КНОПКИ ДЕЙСТВИЙ
            panel1 = new FlowLayoutPanel
            {
                Location = new Point(10, 50),
                Size = new Size(800, 40),
                FlowDirection = FlowDirection.LeftToRight
            };

            btnAdd = new Button
            {
                Text = "Добавить",
                Size = new Size(100, 30),
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += BtnAdd_Click;

            btnEdit = new Button
            {
                Text = "Редактировать",
                Size = new Size(100, 30),
                BackColor = Color.FromArgb(33, 150, 243),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += BtnEdit_Click;

            btnDelete = new Button
            {
                Text = "Удалить",
                Size = new Size(100, 30),
                BackColor = Color.FromArgb(244, 67, 54),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += BtnDelete_Click;

            panel1.Controls.Add(btnAdd);
            panel1.Controls.Add(btnEdit);
            panel1.Controls.Add(btnDelete);

            // ПАНЕЛЬ 2 - ПОИСК И ФИЛЬТР
            panel2 = new FlowLayoutPanel
            {
                Location = new Point(10, 100),
                Size = new Size(800, 40),
                FlowDirection = FlowDirection.LeftToRight
            };

            Label lblSearch = new Label
            {
                Text = "Поиск:",
                Font = new Font("Segoe UI", 10),
                AutoSize = true,
                Margin = new Padding(5, 8, 5, 5)
            };

            txtSearch = new TextBox
            {
                Size = new Size(150, 25),
                Font = new Font("Segoe UI", 10)
            };
            txtSearch.TextChanged += TxtSearch_TextChanged;

            Label lblStatus = new Label
            {
                Text = "Статус:",
                Font = new Font("Segoe UI", 10),
                AutoSize = true,
                Margin = new Padding(10, 8, 5, 5)
            };

            cmbStatus = new ComboBox
            {
                Size = new Size(120, 25),
                Font = new Font("Segoe UI", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbStatus.Items.AddRange(new object[] { "Все", "Pending", "Approved", "Rejected" });
            cmbStatus.SelectedIndex = 0;
            cmbStatus.SelectedIndexChanged += (s, e) => FilterData();

            panel2.Controls.Add(lblSearch);
            panel2.Controls.Add(txtSearch);
            panel2.Controls.Add(lblStatus);
            panel2.Controls.Add(cmbStatus);

            // ТАБЛИЦА
            dgvBatches = new DataGridView
            {
                Location = new Point(10, 150),
                Size = new Size(900, 400),
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            dgvBatches.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvBatches.ColumnHeadersHeight = 30;
            dgvBatches.DefaultCellStyle.Font = new Font("Segoe UI", 10);

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblTotal);
            this.Controls.Add(panel1);
            this.Controls.Add(panel2);
            this.Controls.Add(dgvBatches);
        }

        private void LoadBatches()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT 
                        BatchNumber AS 'Номер партии',
                        ProductionDate AS 'Дата производства',
                        ProductType AS 'Тип продукта',
                        Quantity AS 'Количество',
                        Status AS 'Статус'
                    FROM ProductBatches
                    ORDER BY ProductionDate DESC";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvBatches.DataSource = dt;
                        lblTotal.Text = $"Всего: {dt.Rows.Count}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void FilterData()
        {
            if (dgvBatches.DataSource is DataTable dt)
            {
                string filter = "";
                if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    filter = $"CONVERT([Номер партии], 'System.String') LIKE '%{txtSearch.Text}%'";
                }
                if (cmbStatus.SelectedItem != null && cmbStatus.SelectedItem.ToString() != "Все")
                {
                    if (!string.IsNullOrEmpty(filter))
                        filter += " AND ";
                    filter += $"[Статус] = '{cmbStatus.SelectedItem}'";
                }
                dt.DefaultView.RowFilter = filter;
                lblTotal.Text = $"Всего: {dt.DefaultView.Count}";
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e) => FilterData();

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор!");
                return;
            }
            BatchForm form = new BatchForm(null);
            if (form.ShowDialog() == DialogResult.OK)
                LoadBatches();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор!");
                return;
            }
            if (dgvBatches.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку!");
                return;
            }
            // Здесь нужно передавать ID, но для простоты пока так
            MessageBox.Show("Функция редактирования");
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор!");
                return;
            }
            if (dgvBatches.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку!");
                return;
            }
            if (MessageBox.Show("Удалить?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Удалено");
                LoadBatches();
            }
        }
    }
}