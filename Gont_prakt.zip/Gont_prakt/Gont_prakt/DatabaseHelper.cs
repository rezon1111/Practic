﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gont_prakt
{
    public class DatabaseHelper
    {
        private static string connectionString = "Server=REZONCHIC_;Database=KoksokhimQuality;Integrated Security=True;TrustServerCertificate=True;";

        // Сохраняем последнюю ошибку для диагностики
        public static string LastError { get; private set; }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static bool TestConnection()
        {
            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();
                    LastError = null;
                    return true;
                }
            }
            catch (SqlException ex)
            {
                LastError = $"SQL Error {ex.Number}: {ex.Message}";
                return false;
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                return false;
            }
        }

        public static Dictionary<string, object> GetDashboardStatistics(DateTime startDate, DateTime endDate)
        {
            var stats = new Dictionary<string, object>();

            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();

                    // Общее количество партий
                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM ProductBatches", conn))
                    {
                        stats["TotalBatches"] = (int)cmd.ExecuteScalar();
                    }

                    // Количество анализов за период
                    using (SqlCommand cmd = new SqlCommand(
                        "SELECT COUNT(*) FROM AnalysisResults WHERE AnalysisDate BETWEEN @start AND @end", conn))
                    {
                        cmd.Parameters.AddWithValue("@start", startDate);
                        cmd.Parameters.AddWithValue("@end", endDate);
                        stats["TotalAnalysis"] = (int)cmd.ExecuteScalar();
                    }

                    // Процент прохождения за период
                    using (SqlCommand cmd = new SqlCommand(@"
                        SELECT 
                            ISNULL(COUNT(CASE WHEN IsPassed = 1 THEN 1 END) * 100.0 / NULLIF(COUNT(*), 0), 0) 
                        FROM AnalysisResults 
                        WHERE AnalysisDate BETWEEN @start AND @end", conn))
                    {
                        cmd.Parameters.AddWithValue("@start", startDate);
                        cmd.Parameters.AddWithValue("@end", endDate);
                        stats["PassRate"] = Convert.ToDecimal(cmd.ExecuteScalar());
                    }

                    // Количество пользователей
                    using (SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE IsActive = 1", conn))
                    {
                        stats["ActiveUsers"] = (int)cmd.ExecuteScalar();
                    }

                    // Последние 5 партий
                    using (SqlCommand cmd = new SqlCommand(@"SELECT TOP 5 
                        BatchNumber AS 'Номер партии', 
                        ProductionDate AS 'Дата производства', 
                        ProductType AS 'Тип продукта',
                        Status AS 'Статус',
                        Quantity AS 'Количество'
                        FROM ProductBatches ORDER BY ProductionDate DESC", conn))
                    {
                        DataTable dt = new DataTable();
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                            stats["RecentBatches"] = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                MessageBox.Show($"Ошибка получения статистики: {ex.Message}");
            }

            return stats;
        }

        // Экспорт в CSV
        public static void ExportToCSV(DataGridView dgv, string filePath)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath, false, Encoding.UTF8))
                {
                    // Заголовки
                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        if (dgv.Columns[i].Visible)
                        {
                            sw.Write(dgv.Columns[i].HeaderText);
                            if (i < dgv.Columns.Count - 1) sw.Write(";");
                        }
                    }
                    sw.WriteLine();

                    // Данные
                    foreach (DataGridViewRow row in dgv.Rows)
                    {
                        for (int i = 0; i < dgv.Columns.Count; i++)
                        {
                            if (dgv.Columns[i].Visible && row.Cells[i].Value != null)
                            {
                                string value = row.Cells[i].Value.ToString().Replace(";", ",");
                                sw.Write(value);
                                if (i < dgv.Columns.Count - 1) sw.Write(";");
                            }
                        }
                        sw.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка экспорта: {ex.Message}");
            }
        }

        // Получение данных для графиков
        public static DataTable GetChartData(DateTime startDate, DateTime endDate)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            CAST(ar.AnalysisDate AS DATE) as Date,
                            COUNT(*) as AnalysisCount,
                            AVG(CASE WHEN ar.IsPassed = 1 THEN 100.0 ELSE 0 END) as SuccessRate
                        FROM AnalysisResults ar
                        WHERE ar.AnalysisDate BETWEEN @start AND @end
                        GROUP BY CAST(ar.AnalysisDate AS DATE)
                        ORDER BY Date";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@start", startDate);
                        cmd.Parameters.AddWithValue("@end", endDate);

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }

            return dt;
        }

        // Получение данных о качестве по параметрам
        public static DataTable GetQualityStats(DateTime startDate, DateTime endDate)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            qp.ParameterName,
                            COUNT(*) as Total,
                            AVG(ar.ResultValue) as AvgValue,
                            MIN(ar.ResultValue) as MinValue,
                            MAX(ar.ResultValue) as MaxValue,
                            SUM(CASE WHEN ar.IsPassed = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as SuccessRate
                        FROM AnalysisResults ar
                        JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                        WHERE ar.AnalysisDate BETWEEN @start AND @end
                        GROUP BY qp.ParameterName";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@start", startDate);
                        cmd.Parameters.AddWithValue("@end", endDate);

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }

            return dt;
        }
    }

    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }
    }

    public class ProductBatch
    {
        public int BatchID { get; set; }
        public string BatchNumber { get; set; }
        public DateTime ProductionDate { get; set; }
        public string ProductType { get; set; }
        public decimal Quantity { get; set; }
        public string Status { get; set; }
    }
}