﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Text;

namespace Gont_prakt
{
    public partial class ReportsControl : UserControl
    {
        private User currentUser;
        private DataGridView dgvReports;
        private Panel controlPanel;
        private Button btnGenerateReport;
        private Button btnExportExcel;
        private Button btnExportCsv;
        private Button btnPrint;
        private ComboBox cmbReportType;
        private DateTimePicker dtpFrom;
        private DateTimePicker dtpTo;
        private TextBox txtReportName;
        private RichTextBox rtbPreview;
        private DataTable currentReportData;

        public ReportsControl(User user)
        {
            InitializeComponent();
            currentUser = user;
            SetupUI();
            LoadReports();
        }

        private void SetupUI()
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;

            // Верхняя панель управления
            controlPanel = new Panel
            {
                Height = 250,
                Dock = DockStyle.Top,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            // Заголовок
            Label lblTitle = new Label
            {
                Text = "Генерация отчетов",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 73, 94),
                Location = new Point(15, 10),
                AutoSize = true
            };

            // Тип отчета
            Label lblType = new Label
            {
                Text = "Тип отчета:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 50),
                AutoSize = true
            };

            cmbReportType = new ComboBox
            {
                Location = new Point(120, 47),
                Size = new Size(200, 25),
                Font = new Font("Segoe UI", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbReportType.Items.AddRange(new object[] {
                "Все анализы",
                "Анализы по партиям",
                "Статистика качества",
                "Отчет по браку",
                "Отчет по производительности"
            });
            cmbReportType.SelectedIndex = 0;

            // Название отчета
            Label lblName = new Label
            {
                Text = "Название:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 85),
                AutoSize = true
            };

            txtReportName = new TextBox
            {
                Location = new Point(120, 82),
                Size = new Size(200, 25),
                Font = new Font("Segoe UI", 10),
                Text = $"Отчет_{DateTime.Now:yyyyMMdd_HHmmss}"
            };

            // Период
            Label lblFrom = new Label
            {
                Text = "С:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(15, 120),
                AutoSize = true
            };

            dtpFrom = new DateTimePicker
            {
                Location = new Point(40, 117),
                Size = new Size(130, 25),
                Font = new Font("Segoe UI", 10),
                Format = DateTimePickerFormat.Short,
                Value = DateTime.Now.AddMonths(-1)
            };

            Label lblTo = new Label
            {
                Text = "По:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(180, 120),
                AutoSize = true
            };

            dtpTo = new DateTimePicker
            {
                Location = new Point(210, 117),
                Size = new Size(130, 25),
                Font = new Font("Segoe UI", 10),
                Format = DateTimePickerFormat.Short,
                Value = DateTime.Now
            };

            // Кнопки
            btnGenerateReport = new Button
            {
                Text = "📊 Сформировать отчет",
                Location = new Point(350, 45),
                Size = new Size(160, 40),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnGenerateReport.Click += BtnGenerateReport_Click;

            btnExportExcel = new Button
            {
                Text = "📥 Excel (CSV)",
                Location = new Point(520, 45),
                Size = new Size(110, 40),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExportExcel.Click += BtnExportCsv_Click; // Временно используем CSV

            btnPrint = new Button
            {
                Text = "🖨 Печать",
                Location = new Point(640, 45),
                Size = new Size(80, 40),
                BackColor = Color.FromArgb(155, 89, 182),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnPrint.Click += BtnPrint_Click;

            // Добавляем элементы на панель
            controlPanel.Controls.Add(lblTitle);
            controlPanel.Controls.Add(lblType);
            controlPanel.Controls.Add(cmbReportType);
            controlPanel.Controls.Add(lblName);
            controlPanel.Controls.Add(txtReportName);
            controlPanel.Controls.Add(lblFrom);
            controlPanel.Controls.Add(dtpFrom);
            controlPanel.Controls.Add(lblTo);
            controlPanel.Controls.Add(dtpTo);
            controlPanel.Controls.Add(btnGenerateReport);
            controlPanel.Controls.Add(btnExportExcel);
            controlPanel.Controls.Add(btnPrint);

            // Панель предпросмотра
            Panel previewPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            Label lblPreview = new Label
            {
                Text = "Предпросмотр отчета:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 5),
                AutoSize = true
            };

            rtbPreview = new RichTextBox
            {
                Location = new Point(10, 30),
                Size = new Size(this.Width - 40, 150),
                Font = new Font("Consolas", 10),
                ReadOnly = true,
                BackColor = Color.FromArgb(250, 250, 250),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            previewPanel.Controls.Add(lblPreview);
            previewPanel.Controls.Add(rtbPreview);

            // Таблица отчетов
            Panel tablePanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 200,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            Label lblReports = new Label
            {
                Text = "Сохраненные отчеты:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 5),
                AutoSize = true
            };

            dgvReports = new DataGridView
            {
                Location = new Point(10, 30),
                Size = new Size(this.Width - 40, 160),
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            // Стили для DataGridView
            dgvReports.DefaultCellStyle.Font = new Font("Segoe UI", 9);
            dgvReports.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            dgvReports.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 73, 94);
            dgvReports.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvReports.EnableHeadersVisualStyles = false;

            tablePanel.Controls.Add(lblReports);
            tablePanel.Controls.Add(dgvReports);

            // Добавляем все на форму
            this.Controls.Add(tablePanel);
            this.Controls.Add(previewPanel);
            this.Controls.Add(controlPanel);
        }

        private void LoadReports()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT 
                        ReportID,
                        ReportName AS 'Название отчета',
                        CreatedDate AS 'Дата создания',
                        ReportType AS 'Тип',
                        u.Username AS 'Автор'
                    FROM Reports r
                    JOIN Users u ON r.CreatedBy = u.UserID
                    ORDER BY CreatedDate DESC";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvReports.DataSource = dt;

                        if (dgvReports.Columns["ReportID"] != null)
                            dgvReports.Columns["ReportID"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void BtnGenerateReport_Click(object sender, EventArgs e)
        {
            string reportType = cmbReportType.SelectedItem.ToString();
            DateTime fromDate = dtpFrom.Value;
            DateTime toDate = dtpTo.Value;
            string reportName = txtReportName.Text.Trim();

            if (string.IsNullOrEmpty(reportName))
            {
                reportName = $"Отчет_{DateTime.Now:yyyyMMdd_HHmmss}";
            }

            // Генерируем отчет и получаем DataTable
            currentReportData = GenerateReportData(reportType, fromDate, toDate);

            // Показываем в предпросмотре
            string reportContent = GenerateReportContent(reportType, fromDate, toDate, currentReportData);
            rtbPreview.Clear();
            rtbPreview.AppendText(reportContent);

            // Сохраняем в файл (TXT)
            SaveReportToFile(reportName, reportContent);

            // Сохраняем в БД
            SaveReportToDatabase(reportName, reportType);

            MessageBox.Show($"Отчет '{reportType}' за период с {fromDate.ToShortDateString()} по {toDate.ToShortDateString()} сформирован!\n\n" +
                          $"Сохранен в папке: {Application.StartupPath}\\Reports",
                "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Обновляем список отчетов
            LoadReports();
        }

        private DataTable GenerateReportData(string reportType, DateTime fromDate, DateTime toDate)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "";

                    switch (reportType)
                    {
                        case "Все анализы":
                            query = @"
                                SELECT 
                                    pb.BatchNumber as 'Номер партии',
                                    qp.ParameterName as 'Параметр',
                                    ar.ResultValue as 'Значение',
                                    qp.Unit as 'Ед.изм',
                                    CASE WHEN ar.IsPassed = 1 THEN 'Да' ELSE 'Нет' END as 'Соответствует',
                                    u.FullName as 'Аналитик',
                                    ar.AnalysisDate as 'Дата анализа',
                                    ar.Notes as 'Примечания'
                                FROM AnalysisResults ar
                                JOIN ProductBatches pb ON ar.BatchID = pb.BatchID
                                JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                                JOIN Users u ON ar.AnalyzedBy = u.UserID
                                WHERE ar.AnalysisDate BETWEEN @from AND @to
                                ORDER BY ar.AnalysisDate DESC";
                            break;

                        case "Отчет по браку":
                            query = @"
                                SELECT 
                                    pb.BatchNumber as 'Номер партии',
                                    pb.ProductType as 'Тип продукта',
                                    qp.ParameterName as 'Параметр',
                                    ar.ResultValue as 'Значение',
                                    qp.Unit as 'Ед.изм',
                                    qp.MinValue as 'Норма мин',
                                    qp.MaxValue as 'Норма макс',
                                    u.FullName as 'Аналитик',
                                    ar.AnalysisDate as 'Дата',
                                    ar.Notes as 'Примечания'
                                FROM AnalysisResults ar
                                JOIN ProductBatches pb ON ar.BatchID = pb.BatchID
                                JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                                JOIN Users u ON ar.AnalyzedBy = u.UserID
                                WHERE ar.IsPassed = 0 
                                    AND ar.AnalysisDate BETWEEN @from AND @to
                                ORDER BY ar.AnalysisDate DESC";
                            break;

                        case "Статистика качества":
                            query = @"
                                SELECT 
                                    qp.ParameterName as 'Параметр',
                                    COUNT(*) as 'Всего анализов',
                                    AVG(ar.ResultValue) as 'Среднее значение',
                                    MIN(ar.ResultValue) as 'Минимум',
                                    MAX(ar.ResultValue) as 'Максимум',
                                    SUM(CASE WHEN ar.IsPassed = 0 THEN 1 ELSE 0 END) as 'Брак',
                                    SUM(CASE WHEN ar.IsPassed = 1 THEN 1 ELSE 0 END) as 'Годных'
                                FROM AnalysisResults ar
                                JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                                WHERE ar.AnalysisDate BETWEEN @from AND @to
                                GROUP BY qp.ParameterName";
                            break;

                        case "Анализы по партиям":
                            query = @"
                                SELECT 
                                    pb.BatchNumber as 'Партия',
                                    pb.ProductType as 'Тип',
                                    COUNT(ar.ResultID) as 'Анализов',
                                    SUM(CASE WHEN ar.IsPassed = 1 THEN 1 ELSE 0 END) as 'Годных',
                                    SUM(CASE WHEN ar.IsPassed = 0 THEN 1 ELSE 0 END) as 'Брак'
                                FROM ProductBatches pb
                                LEFT JOIN AnalysisResults ar ON pb.BatchID = ar.BatchID 
                                    AND ar.AnalysisDate BETWEEN @from AND @to
                                GROUP BY pb.BatchNumber, pb.ProductType
                                ORDER BY pb.BatchNumber";
                            break;

                        case "Отчет по производительности":
                            query = @"
                                SELECT 
                                    CAST(ar.AnalysisDate AS DATE) as 'Дата',
                                    COUNT(*) as 'Анализов',
                                    COUNT(DISTINCT ar.AnalyzedBy) as 'Аналитиков',
                                    COUNT(DISTINCT ar.BatchID) as 'Партий',
                                    AVG(CASE WHEN ar.IsPassed = 1 THEN 100.0 ELSE 0 END) as 'Успешность, %'
                                FROM AnalysisResults ar
                                WHERE ar.AnalysisDate BETWEEN @from AND @to
                                GROUP BY CAST(ar.AnalysisDate AS DATE)
                                ORDER BY 'Дата' DESC";
                            break;
                    }

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@from", fromDate);
                        cmd.Parameters.AddWithValue("@to", toDate.AddDays(1));

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dt;
        }

        private string GenerateReportContent(string reportType, DateTime fromDate, DateTime toDate, DataTable data)
        {
            string content = $"ОТЧЕТ: {reportType}\n";
            content += $"Период: {fromDate.ToShortDateString()} - {toDate.ToShortDateString()}\n";
            content += $"Дата формирования: {DateTime.Now:dd.MM.yyyy HH:mm:ss}\n";
            content += $"Автор: {currentUser.FullName}\n";
            content += new string('=', 80) + "\n\n";

            if (data.Rows.Count == 0)
            {
                content += "Нет данных за выбранный период.\n";
            }
            else
            {
                // Заголовки
                foreach (DataColumn col in data.Columns)
                {
                    content += $"{col.ColumnName,-20}";
                }
                content += "\n";
                content += new string('-', 80) + "\n";

                // Данные
                foreach (DataRow row in data.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        string value = item?.ToString() ?? "";
                        if (value.Length > 20) value = value.Substring(0, 17) + "...";
                        content += $"{value,-20}";
                    }
                    content += "\n";
                }

                content += $"\nВсего записей: {data.Rows.Count}";
            }

            return content;
        }

        private void SaveReportToFile(string reportName, string content)
        {
            try
            {
                string reportsPath = Path.Combine(Application.StartupPath, "Reports");
                if (!Directory.Exists(reportsPath))
                {
                    Directory.CreateDirectory(reportsPath);
                }

                string fileName = $"{reportName}.txt";
                string filePath = Path.Combine(reportsPath, fileName);

                int counter = 1;
                while (File.Exists(filePath))
                {
                    fileName = $"{reportName}_{counter}.txt";
                    filePath = Path.Combine(reportsPath, fileName);
                    counter++;
                }

                File.WriteAllText(filePath, content, Encoding.UTF8);

                // Сохраняем также в CSV для удобства
                string csvPath = Path.Combine(reportsPath, $"{reportName}.csv");
                SaveDataTableToCsv(currentReportData, csvPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения файла: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SaveDataTableToCsv(DataTable data, string filePath)
        {
            if (data == null || data.Rows.Count == 0) return;

            using (StreamWriter sw = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                // Заголовки
                for (int i = 0; i < data.Columns.Count; i++)
                {
                    sw.Write(data.Columns[i].ColumnName);
                    if (i < data.Columns.Count - 1) sw.Write(";");
                }
                sw.WriteLine();

                // Данные
                foreach (DataRow row in data.Rows)
                {
                    for (int i = 0; i < data.Columns.Count; i++)
                    {
                        string value = row[i]?.ToString()?.Replace(";", ",") ?? "";
                        sw.Write(value);
                        if (i < data.Columns.Count - 1) sw.Write(";");
                    }
                    sw.WriteLine();
                }
            }
        }

        private void SaveReportToDatabase(string reportName, string reportType)
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"INSERT INTO Reports (ReportName, CreatedBy, ReportType, CreatedDate) 
                                   VALUES (@name, @user, @type, @date)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", reportName);
                        cmd.Parameters.AddWithValue("@user", currentUser.UserID);
                        cmd.Parameters.AddWithValue("@type", reportType);
                        cmd.Parameters.AddWithValue("@date", DateTime.Now);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения в БД: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnExportCsv_Click(object sender, EventArgs e)
        {
            if (currentReportData == null || currentReportData.Rows.Count == 0)
            {
                MessageBox.Show("Сначала сформируйте отчет!", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv|Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*",
                DefaultExt = "csv",
                FileName = $"{txtReportName.Text}.csv"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    SaveDataTableToCsv(currentReportData, saveDialog.FileName);

                    MessageBox.Show($"Отчет успешно сохранен!\n\n{saveDialog.FileName}", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Спрашиваем, открыть ли файл
                    if (MessageBox.Show("Открыть файл?", "Вопрос",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start(saveDialog.FileName);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(rtbPreview.Text))
            {
                MessageBox.Show("Сначала сформируйте отчет!", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Простая печать через RichTextBox
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                // Здесь можно добавить реальную печать
                MessageBox.Show("Функция печати будет доступна в следующей версии!\n\n" +
                               "Пока вы можете сохранить отчет и открыть его в Word/Excel для печати.",
                    "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}