﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class AnalysisControl : UserControl
    {
        private User currentUser;
        private DataGridView dgvAnalysis;
        private Panel controlPanel;
        private Button btnAdd;
        private Button btnView;
        private ComboBox cmbBatch;
        private ComboBox cmbParameter;
        private TextBox txtResult;
        private TextBox txtNotes;
        private Button btnSave;

        public AnalysisControl(User user)
        {
            InitializeComponent();
            currentUser = user;
            LoadAnalysis();
            LoadBatches();
            LoadParameters();
        }

        private void InitializeComponent()
        {
            this.dgvAnalysis = new DataGridView();
            this.controlPanel = new Panel();
            this.btnAdd = new Button();
            this.btnView = new Button();
            this.cmbBatch = new ComboBox();
            this.cmbParameter = new ComboBox();
            this.txtResult = new TextBox();
            this.txtNotes = new TextBox();
            this.btnSave = new Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalysis)).BeginInit();
            this.controlPanel.SuspendLayout();
            this.SuspendLayout();

            // AnalysisControl
            this.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.Name = "AnalysisControl";
            this.Size = new System.Drawing.Size(800, 600);

            // controlPanel
            this.controlPanel.BackColor = System.Drawing.Color.White;
            this.controlPanel.Dock = DockStyle.Top;
            this.controlPanel.Height = 150;
            this.controlPanel.Padding = new Padding(10);

            // Labels
            Label lblBatch = new Label { Text = "Партия:", Location = new System.Drawing.Point(20, 15), Size = new System.Drawing.Size(80, 25) };
            Label lblParameter = new Label { Text = "Параметр:", Location = new System.Drawing.Point(20, 50), Size = new System.Drawing.Size(80, 25) };
            Label lblResult = new Label { Text = "Результат:", Location = new System.Drawing.Point(20, 85), Size = new System.Drawing.Size(80, 25) };
            Label lblNotes = new Label { Text = "Примечания:", Location = new System.Drawing.Point(300, 15), Size = new System.Drawing.Size(80, 25) };

            // Controls
            cmbBatch.Location = new System.Drawing.Point(100, 12);
            cmbBatch.Size = new System.Drawing.Size(180, 25);
            cmbBatch.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbParameter.Location = new System.Drawing.Point(100, 47);
            cmbParameter.Size = new System.Drawing.Size(180, 25);
            cmbParameter.DropDownStyle = ComboBoxStyle.DropDownList;

            txtResult.Location = new System.Drawing.Point(100, 82);
            txtResult.Size = new System.Drawing.Size(180, 25);

            txtNotes.Location = new System.Drawing.Point(380, 12);
            txtNotes.Size = new System.Drawing.Size(200, 60);
            txtNotes.Multiline = true;

            btnSave.Text = "Сохранить анализ";
            btnSave.Location = new System.Drawing.Point(380, 80);
            btnSave.Size = new System.Drawing.Size(150, 30);
            btnSave.BackColor = System.Drawing.Color.FromArgb(46, 204, 113);
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.ForeColor = System.Drawing.Color.White;
            btnSave.Click += BtnSave_Click;

            btnAdd.Text = "Новый анализ";
            btnAdd.Location = new System.Drawing.Point(600, 12);
            btnAdd.Size = new System.Drawing.Size(120, 35);
            btnAdd.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = System.Drawing.Color.White;
            btnAdd.Click += BtnAdd_Click;

            btnView.Text = "Просмотр";
            btnView.Location = new System.Drawing.Point(600, 57);
            btnView.Size = new System.Drawing.Size(120, 35);
            btnView.BackColor = System.Drawing.Color.FromArgb(155, 89, 182);
            btnView.FlatStyle = FlatStyle.Flat;
            btnView.ForeColor = System.Drawing.Color.White;
            btnView.Click += BtnView_Click;

            controlPanel.Controls.Add(lblBatch);
            controlPanel.Controls.Add(lblParameter);
            controlPanel.Controls.Add(lblResult);
            controlPanel.Controls.Add(lblNotes);
            controlPanel.Controls.Add(cmbBatch);
            controlPanel.Controls.Add(cmbParameter);
            controlPanel.Controls.Add(txtResult);
            controlPanel.Controls.Add(txtNotes);
            controlPanel.Controls.Add(btnSave);
            controlPanel.Controls.Add(btnAdd);
            controlPanel.Controls.Add(btnView);

            // dgvAnalysis
            this.dgvAnalysis.AllowUserToAddRows = false;
            this.dgvAnalysis.AllowUserToDeleteRows = false;
            this.dgvAnalysis.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAnalysis.BackgroundColor = System.Drawing.Color.White;
            this.dgvAnalysis.Dock = DockStyle.Fill;
            this.dgvAnalysis.Location = new System.Drawing.Point(0, 150);
            this.dgvAnalysis.Name = "dgvAnalysis";
            this.dgvAnalysis.ReadOnly = true;
            this.dgvAnalysis.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            this.Controls.Add(this.dgvAnalysis);
            this.Controls.Add(this.controlPanel);

            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalysis)).EndInit();
            this.controlPanel.ResumeLayout(false);
            this.controlPanel.PerformLayout();
            this.ResumeLayout(false);
        }

        private void LoadBatches()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT BatchID, BatchNumber FROM ProductBatches WHERE Status = 'Pending'";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            cmbBatch.Items.Clear();
                            while (reader.Read())
                            {
                                cmbBatch.Items.Add(new ComboboxItem
                                {
                                    Text = reader["BatchNumber"].ToString(),
                                    Value = reader["BatchID"]
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки партий: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadParameters()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT ParameterID, ParameterName FROM QualityParameters";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            cmbParameter.Items.Clear();
                            while (reader.Read())
                            {
                                cmbParameter.Items.Add(new ComboboxItem
                                {
                                    Text = reader["ParameterName"].ToString(),
                                    Value = reader["ParameterID"]
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки параметров: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadAnalysis()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT 
                        ar.ResultID,
                        pb.BatchNumber AS 'Партия',
                        qp.ParameterName AS 'Параметр',
                        ar.ResultValue AS 'Значение',
                        u.FullName AS 'Аналитик',
                        ar.AnalysisDate AS 'Дата анализа',
                        CASE WHEN ar.IsPassed = 1 THEN 'Да' ELSE 'Нет' END AS 'Соответствует'
                    FROM AnalysisResults ar
                    JOIN ProductBatches pb ON ar.BatchID = pb.BatchID
                    JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                    JOIN Users u ON ar.AnalyzedBy = u.UserID
                    ORDER BY ar.AnalysisDate DESC";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvAnalysis.DataSource = dt;

                        if (dgvAnalysis.Columns["ResultID"] != null)
                            dgvAnalysis.Columns["ResultID"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки анализов: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (cmbBatch.SelectedItem == null || cmbParameter.SelectedItem == null || string.IsNullOrWhiteSpace(txtResult.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int batchId = (int)((ComboboxItem)cmbBatch.SelectedItem).Value;
                int parameterId = (int)((ComboboxItem)cmbParameter.SelectedItem).Value;
                decimal result = decimal.Parse(txtResult.Text);

                // Проверка соответствия нормам
                bool isPassed = CheckQuality(batchId, parameterId, result);

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"INSERT INTO AnalysisResults (BatchID, ParameterID, AnalyzedBy, ResultValue, IsPassed, Notes)
                                   VALUES (@batch, @param, @user, @result, @passed, @notes)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@batch", batchId);
                        cmd.Parameters.AddWithValue("@param", parameterId);
                        cmd.Parameters.AddWithValue("@user", currentUser.UserID);
                        cmd.Parameters.AddWithValue("@result", result);
                        cmd.Parameters.AddWithValue("@passed", isPassed);
                        cmd.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(txtNotes.Text) ? DBNull.Value : (object)txtNotes.Text);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show(isPassed ? "Анализ сохранен. Параметр соответствует нормам!" :
                    "Анализ сохранен. Параметр НЕ соответствует нормам!",
                    "Информация", MessageBoxButtons.OK,
                    isPassed ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                ClearForm();
                LoadAnalysis();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool CheckQuality(int batchId, int parameterId, decimal result)
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT MinValue, MaxValue FROM QualityParameters WHERE ParameterID = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", parameterId);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                decimal min = reader.GetDecimal(0);
                                decimal max = reader.GetDecimal(1);
                                return result >= min && result <= max;
                            }
                        }
                    }
                }
            }
            catch { }
            return false;
        }

        private void ClearForm()
        {
            cmbBatch.SelectedIndex = -1;
            cmbParameter.SelectedIndex = -1;
            txtResult.Clear();
            txtNotes.Clear();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            if (dgvAnalysis.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите анализ для просмотра!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Здесь можно открыть форму с деталями анализа
            MessageBox.Show("Детальный просмотр анализа будет доступен в следующей версии!",
                "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    public class ComboboxItem
    {
        public string Text { get; set; }
        public object Value { get; set; }
        public override string ToString() => Text;
    }
}