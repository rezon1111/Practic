﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class ParametersControl : UserControl
    {
        private User currentUser;
        private DataGridView dgvParameters;
        private Panel controlPanel;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private TextBox txtSearch;

        public ParametersControl(User user)
        {
            InitializeComponent();
            currentUser = user;
            LoadParameters();
        }

        private void InitializeComponent()
        {
            dgvParameters = new DataGridView();
            controlPanel = new Panel();
            txtSearch = new TextBox();
            btnAdd = new Button();
            btnEdit = new Button();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvParameters).BeginInit();
            controlPanel.SuspendLayout();
            SuspendLayout();
            // 
            // dgvParameters
            // 
            dgvParameters.AllowUserToAddRows = false;
            dgvParameters.AllowUserToDeleteRows = false;
            dgvParameters.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvParameters.BackgroundColor = Color.White;
            dgvParameters.ColumnHeadersHeight = 29;
            dgvParameters.Dock = DockStyle.Fill;
            dgvParameters.Location = new Point(0, 60);
            dgvParameters.Name = "dgvParameters";
            dgvParameters.ReadOnly = true;
            dgvParameters.RowHeadersWidth = 51;
            dgvParameters.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvParameters.Size = new Size(800, 540);
            dgvParameters.TabIndex = 0;
            // 
            // controlPanel
            // 
            controlPanel.BackColor = Color.White;
            controlPanel.Controls.Add(txtSearch);
            controlPanel.Controls.Add(btnAdd);
            controlPanel.Controls.Add(btnEdit);
            controlPanel.Controls.Add(btnDelete);
            controlPanel.Dock = DockStyle.Top;
            controlPanel.Location = new Point(0, 0);
            controlPanel.Name = "controlPanel";
            controlPanel.Padding = new Padding(10);
            controlPanel.Size = new Size(800, 60);
            controlPanel.TabIndex = 1;
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Segoe UI", 10F);
            txtSearch.Location = new Point(438, 15);
            txtSearch.Name = "txtSearch";
            txtSearch.PlaceholderText = "Поиск...";
            txtSearch.Size = new Size(200, 30);
            txtSearch.TabIndex = 0;
            txtSearch.TextChanged += TxtSearch_TextChanged;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(46, 204, 113);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(20, 10);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 35);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "Добавить";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += BtnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.FromArgb(52, 152, 219);
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnEdit.ForeColor = Color.White;
            btnEdit.Location = new Point(130, 10);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(100, 35);
            btnEdit.TabIndex = 2;
            btnEdit.Text = "Редактировать";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += BtnEdit_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(231, 76, 60);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(240, 10);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(100, 35);
            btnDelete.TabIndex = 3;
            btnDelete.Text = "Удалить";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += BtnDelete_Click;
            // 
            // ParametersControl
            // 
            BackColor = Color.FromArgb(240, 240, 240);
            Controls.Add(dgvParameters);
            Controls.Add(controlPanel);
            Name = "ParametersControl";
            Size = new Size(800, 600);
            ((System.ComponentModel.ISupportInitialize)dgvParameters).EndInit();
            controlPanel.ResumeLayout(false);
            controlPanel.PerformLayout();
            ResumeLayout(false);
        }

        private void LoadParameters()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT 
                        ParameterID,
                        ParameterName AS 'Параметр',
                        Unit AS 'Единица измерения',
                        MinValue AS 'Мин. значение',
                        MaxValue AS 'Макс. значение',
                        Description AS 'Описание'
                    FROM QualityParameters";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvParameters.DataSource = dt;

                        if (dgvParameters.Columns["ParameterID"] != null)
                            dgvParameters.Columns["ParameterID"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки параметров: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            if (dgvParameters.DataSource is DataTable dt)
            {
                dt.DefaultView.RowFilter = string.IsNullOrWhiteSpace(txtSearch.Text) ? "" :
                    $"CONVERT([Параметр], 'System.String') LIKE '%{txtSearch.Text}%'";
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор может добавлять параметры!", "Доступ запрещен",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (ParameterForm form = new ParameterForm(null))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadParameters();
                }
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор может редактировать параметры!", "Доступ запрещен",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dgvParameters.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите параметр для редактирования!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int parameterId = Convert.ToInt32(dgvParameters.SelectedRows[0].Cells["ParameterID"].Value);

            using (ParameterForm form = new ParameterForm(parameterId))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadParameters();
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (currentUser.Role != "Admin")
            {
                MessageBox.Show("Только администратор может удалять параметры!", "Доступ запрещен",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dgvParameters.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите параметр для удаления!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Вы уверены, что хотите удалить выбранный параметр?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int parameterId = Convert.ToInt32(dgvParameters.SelectedRows[0].Cells["ParameterID"].Value);

                try
                {
                    using (SqlConnection conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "DELETE FROM QualityParameters WHERE ParameterID = @id";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", parameterId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadParameters();
                    MessageBox.Show("Параметр успешно удален!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}