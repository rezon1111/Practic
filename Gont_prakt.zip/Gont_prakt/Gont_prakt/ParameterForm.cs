﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class ParameterForm : Form
    {
        private int? parameterId;
        private TextBox txtParameterName;
        private TextBox txtUnit;
        private NumericUpDown nudMinValue;
        private NumericUpDown nudMaxValue;
        private TextBox txtDescription;
        private Button btnSave;
        private Button btnCancel;

        public ParameterForm(int? id = null)
        {
            InitializeComponent();
            parameterId = id;

            if (parameterId.HasValue)
            {
                this.Text = "Редактирование параметра";
                LoadParameterData();
            }
            else
            {
                this.Text = "Новый параметр";
            }
        }

        private void InitializeComponent()
        {
            this.txtParameterName = new TextBox();
            this.txtUnit = new TextBox();
            this.nudMinValue = new NumericUpDown();
            this.nudMaxValue = new NumericUpDown();
            this.txtDescription = new TextBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxValue)).BeginInit();
            this.SuspendLayout();

            // Form settings
            this.ClientSize = new System.Drawing.Size(450, 350);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            int yPos = 20;
            int labelWidth = 120;
            int controlWidth = 250;

            // Parameter Name
            Label lblParameterName = new Label
            {
                Text = "Название параметра:",
                Location = new System.Drawing.Point(20, yPos + 5),
                Size = new System.Drawing.Size(labelWidth, 25)
            };
            txtParameterName.Location = new System.Drawing.Point(150, yPos);
            txtParameterName.Size = new System.Drawing.Size(controlWidth, 25);
            this.Controls.Add(lblParameterName);
            this.Controls.Add(txtParameterName);

            // Unit
            yPos += 35;
            Label lblUnit = new Label
            {
                Text = "Единица измерения:",
                Location = new System.Drawing.Point(20, yPos + 5),
                Size = new System.Drawing.Size(labelWidth, 25)
            };
            txtUnit.Location = new System.Drawing.Point(150, yPos);
            txtUnit.Size = new System.Drawing.Size(controlWidth, 25);
            this.Controls.Add(lblUnit);
            this.Controls.Add(txtUnit);

            // Min Value
            yPos += 35;
            Label lblMinValue = new Label
            {
                Text = "Мин. значение:",
                Location = new System.Drawing.Point(20, yPos + 5),
                Size = new System.Drawing.Size(labelWidth, 25)
            };
            nudMinValue.Location = new System.Drawing.Point(150, yPos);
            nudMinValue.Size = new System.Drawing.Size(controlWidth, 25);
            nudMinValue.DecimalPlaces = 3;
            nudMinValue.Maximum = 10000;
            nudMinValue.Minimum = -10000;
            this.Controls.Add(lblMinValue);
            this.Controls.Add(nudMinValue);

            // Max Value
            yPos += 35;
            Label lblMaxValue = new Label
            {
                Text = "Макс. значение:",
                Location = new System.Drawing.Point(20, yPos + 5),
                Size = new System.Drawing.Size(labelWidth, 25)
            };
            nudMaxValue.Location = new System.Drawing.Point(150, yPos);
            nudMaxValue.Size = new System.Drawing.Size(controlWidth, 25);
            nudMaxValue.DecimalPlaces = 3;
            nudMaxValue.Maximum = 10000;
            nudMaxValue.Minimum = -10000;
            this.Controls.Add(lblMaxValue);
            this.Controls.Add(nudMaxValue);

            // Description
            yPos += 35;
            Label lblDescription = new Label
            {
                Text = "Описание:",
                Location = new System.Drawing.Point(20, yPos + 5),
                Size = new System.Drawing.Size(labelWidth, 25)
            };
            txtDescription.Location = new System.Drawing.Point(150, yPos);
            txtDescription.Size = new System.Drawing.Size(controlWidth, 60);
            txtDescription.Multiline = true;
            this.Controls.Add(lblDescription);
            this.Controls.Add(txtDescription);

            // Buttons
            btnSave.Text = "Сохранить";
            btnSave.Location = new System.Drawing.Point(150, 280);
            btnSave.Size = new System.Drawing.Size(100, 30);
            btnSave.BackColor = System.Drawing.Color.FromArgb(46, 204, 113);
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.ForeColor = System.Drawing.Color.White;
            btnSave.Click += BtnSave_Click;

            btnCancel.Text = "Отмена";
            btnCancel.Location = new System.Drawing.Point(270, 280);
            btnCancel.Size = new System.Drawing.Size(100, 30);
            btnCancel.BackColor = System.Drawing.Color.FromArgb(149, 165, 166);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.ForeColor = System.Drawing.Color.White;
            btnCancel.Click += (s, e) => this.Close();

            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);

            ((System.ComponentModel.ISupportInitialize)(this.nudMinValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxValue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void LoadParameterData()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT ParameterName, Unit, MinValue, MaxValue, Description 
                                   FROM QualityParameters WHERE ParameterID = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", parameterId.Value);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtParameterName.Text = reader["ParameterName"].ToString();
                                txtUnit.Text = reader["Unit"].ToString();
                                nudMinValue.Value = Convert.ToDecimal(reader["MinValue"]);
                                nudMaxValue.Value = Convert.ToDecimal(reader["MaxValue"]);
                                txtDescription.Text = reader["Description"].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtParameterName.Text))
            {
                MessageBox.Show("Введите название параметра!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query;

                    if (parameterId.HasValue)
                    {
                        query = @"UPDATE QualityParameters 
                                SET ParameterName = @name, Unit = @unit, 
                                    MinValue = @min, MaxValue = @max, Description = @desc
                                WHERE ParameterID = @id";
                    }
                    else
                    {
                        query = @"INSERT INTO QualityParameters (ParameterName, Unit, MinValue, MaxValue, Description)
                                VALUES (@name, @unit, @min, @max, @desc)";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", txtParameterName.Text.Trim());
                        cmd.Parameters.AddWithValue("@unit", string.IsNullOrWhiteSpace(txtUnit.Text) ? DBNull.Value : (object)txtUnit.Text.Trim());
                        cmd.Parameters.AddWithValue("@min", nudMinValue.Value);
                        cmd.Parameters.AddWithValue("@max", nudMaxValue.Value);
                        cmd.Parameters.AddWithValue("@desc", string.IsNullOrWhiteSpace(txtDescription.Text) ? DBNull.Value : (object)txtDescription.Text.Trim());

                        if (parameterId.HasValue)
                        {
                            cmd.Parameters.AddWithValue("@id", parameterId.Value);
                        }

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}