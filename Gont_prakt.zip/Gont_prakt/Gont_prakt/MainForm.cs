﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Gont_prakt
{
    public class MainForm : Form
    {
        private User currentUser;
        private Panel sidebarPanel;
        private Panel contentPanel;
        private Panel topPanel;
        private Button btnDashboard;
        private Button btnBatches;
        private Button btnAnalysis;
        private Button btnParameters;
        private Button btnReports;
        private Button btnUsers;
        private Button btnLogout;
        private Label lblWelcome;
        private Label lblRole;
        private PictureBox pictureBoxLogo;
        private System.Windows.Forms.Timer statusTimer;
        private Label lblStatus;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
        private Panel userPanel;

        public MainForm(User user)
        {
            currentUser = user;
            InitializeComponent();
            this.Load += MainForm_Load;
        }

        private void InitializeComponent()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Size = new Size(1300, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);

            // ВЕРХНЯЯ ПАНЕЛЬ
            topPanel = new Panel
            {
                Height = 40,
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(52, 73, 94)
            };

            Label lblTitle = new Label
            {
                Text = "Коксохимзавод - Система контроля качества",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(10, 10),
                AutoSize = true
            };

            btnMinimize = new Button
            {
                Text = "─",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(30, 30),
                Location = new Point(1210, 5),
                Cursor = Cursors.Hand
            };
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.Click += (s, e) => this.WindowState = FormWindowState.Minimized;

            btnMaximize = new Button
            {
                Text = "□",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(30, 30),
                Location = new Point(1240, 5),
                Cursor = Cursors.Hand
            };
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.Click += (s, e) =>
            {
                if (this.WindowState == FormWindowState.Normal)
                    this.WindowState = FormWindowState.Maximized;
                else
                    this.WindowState = FormWindowState.Normal;
            };

            btnClose = new Button
            {
                Text = "×",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(192, 57, 43),
                FlatStyle = FlatStyle.Flat,
                Size = new Size(30, 30),
                Location = new Point(1270, 5),
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => Application.Exit();

            topPanel.Controls.Add(lblTitle);
            topPanel.Controls.Add(btnMinimize);
            topPanel.Controls.Add(btnMaximize);
            topPanel.Controls.Add(btnClose);

            // БОКОВАЯ ПАНЕЛЬ
            sidebarPanel = new Panel
            {
                Width = 260,
                Dock = DockStyle.Left,
                BackColor = Color.FromArgb(44, 62, 80)
            };

            // Логотип
            pictureBoxLogo = new PictureBox
            {
                Size = new Size(80, 80),
                Location = new Point(90, 20),
                BackColor = Color.Transparent
            };
            pictureBoxLogo.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;

                Rectangle rect = new Rectangle(0, 0, 79, 79);
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    rect,
                    Color.FromArgb(52, 152, 219),
                    Color.FromArgb(41, 128, 185),
                    LinearGradientMode.ForwardDiagonal))
                {
                    g.FillEllipse(brush, rect);
                }

                using (Font font = new Font("Segoe UI", 20, FontStyle.Bold))
                {
                    g.DrawString("КХЗ", font, Brushes.White, 18, 25);
                }
            };

            // Панель пользователя
            userPanel = new Panel
            {
                Location = new Point(20, 120),
                Size = new Size(220, 70),
                BackColor = Color.FromArgb(52, 73, 94)
            };

            lblWelcome = new Label
            {
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(10, 10),
                AutoSize = true
            };

            lblRole = new Label
            {
                Font = new Font("Segoe UI", 8),
                ForeColor = Color.FromArgb(189, 195, 199),
                Location = new Point(10, 30),
                AutoSize = true
            };

            lblStatus = new Label
            {
                Font = new Font("Segoe UI", 8),
                ForeColor = Color.FromArgb(46, 204, 113),
                Location = new Point(10, 45),
                AutoSize = true,
                Text = "● Система онлайн"
            };

            userPanel.Controls.Add(lblWelcome);
            userPanel.Controls.Add(lblRole);
            userPanel.Controls.Add(lblStatus);

            // КНОПКИ МЕНЮ
            int yPos = 210;

            btnDashboard = CreateMenuButton("🏠", "Панель управления", yPos);
            btnDashboard.Click += (s, e) => LoadControl(new DashboardControl(currentUser));

            yPos += 50;
            btnBatches = CreateMenuButton("📦", "Партии продукции", yPos);
            btnBatches.Click += (s, e) => LoadControl(new BatchesControl(currentUser));

            yPos += 50;
            btnAnalysis = CreateMenuButton("🔬", "Анализы качества", yPos);
            btnAnalysis.Click += (s, e) => LoadControl(new AnalysisControl(currentUser));

            yPos += 50;
            btnParameters = CreateMenuButton("⚙", "Параметры качества", yPos);
            btnParameters.Click += (s, e) => LoadControl(new ParametersControl(currentUser));

            yPos += 50;
            btnReports = CreateMenuButton("📊", "Отчеты", yPos);
            btnReports.Click += (s, e) => LoadControl(new ReportsControl(currentUser));

            yPos += 50;
            btnUsers = CreateMenuButton("👥", "Пользователи", yPos);
            btnUsers.Visible = false;
            btnUsers.Click += (s, e) => ShowUserManagement();

            // КНОПКА ВЫХОДА - БОЛЬШАЯ И ВИДНАЯ
            btnLogout = new Button
            {
                Text = "🚪  ВЫХОД ИЗ СИСТЕМЫ",
                Location = new Point(20, 650),
                Width = 220,
                Height = 50,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                BackColor = Color.FromArgb(192, 57, 43),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(15, 0, 0, 0),
                Cursor = Cursors.Hand
            };
            btnLogout.Click += BtnLogout_Click;

            // Сборка боковой панели
            sidebarPanel.Controls.Add(pictureBoxLogo);
            sidebarPanel.Controls.Add(userPanel);
            sidebarPanel.Controls.Add(btnDashboard);
            sidebarPanel.Controls.Add(btnBatches);
            sidebarPanel.Controls.Add(btnAnalysis);
            sidebarPanel.Controls.Add(btnParameters);
            sidebarPanel.Controls.Add(btnReports);
            sidebarPanel.Controls.Add(btnUsers);
            sidebarPanel.Controls.Add(btnLogout);

            // Панель контента
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(10)
            };

            // Добавляем все на форму
            this.Controls.Add(contentPanel);
            this.Controls.Add(sidebarPanel);
            this.Controls.Add(topPanel);

            // Таймер
            statusTimer = new System.Windows.Forms.Timer();
            statusTimer.Interval = 30000;
            statusTimer.Tick += (s, e) => UpdateStatus();
            statusTimer.Start();
        }

        private Button CreateMenuButton(string icon, string text, int yPos)
        {
            Button btn = new Button
            {
                Text = $"{icon}   {text}",
                Location = new Point(20, yPos),
                Width = 220,
                Height = 45,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                BackColor = Color.Transparent,
                ForeColor = Color.FromArgb(189, 195, 199),
                Font = new Font("Segoe UI", 10),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(15, 0, 0, 0),
                Cursor = Cursors.Hand
            };

            btn.MouseEnter += (s, e) => {
                btn.ForeColor = Color.White;
                btn.BackColor = Color.FromArgb(52, 152, 219);
            };
            btn.MouseLeave += (s, e) => {
                btn.ForeColor = Color.FromArgb(189, 195, 199);
                btn.BackColor = Color.Transparent;
            };

            return btn;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = currentUser.FullName;
            lblRole.Text = currentUser.Role == "Admin" ? "Администратор" : "Пользователь";

            if (currentUser.Role == "Admin")
            {
                btnUsers.Visible = true;
            }

            LoadControl(new DashboardControl(currentUser));
            UpdateStatus();
        }

        private void LoadControl(UserControl control)
        {
            contentPanel.Controls.Clear();
            control.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(control);
        }

        private void ShowUserManagement()
        {
            if (currentUser.Role == "Admin")
            {
                UserManagementForm userForm = new UserManagementForm();
                userForm.ShowDialog(); // Открывается как модальное окно
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы уверены, что хотите выйти?",
                "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                statusTimer.Stop();
                this.Hide();
                LoginForm loginForm = new LoginForm();
                loginForm.ShowDialog();
                this.Close();
            }
        }

        private void UpdateStatus()
        {
            if (DatabaseHelper.TestConnection())
            {
                lblStatus.Text = "● Система онлайн";
                lblStatus.ForeColor = Color.FromArgb(46, 204, 113);
            }
            else
            {
                lblStatus.Text = "● Нет подключения к БД";
                lblStatus.ForeColor = Color.FromArgb(231, 76, 60);
            }
        }
    }
}