﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class BatchForm : Form
    {
        private int? batchId;

        public BatchForm(int? id = null)
        {
            InitializeComponent();
            batchId = id;

            if (batchId.HasValue)
            {
                this.Text = "Редактирование партии";
                lblTitle.Text = "Редактирование партии";
                LoadBatchData();
            }
            else
            {
                this.Text = "Новая партия";
                lblTitle.Text = "Новая партия";
                cmbStatus.SelectedIndex = 0;
            }
        }

        private void LoadBatchData()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT BatchNumber, ProductionDate, ProductType, Quantity, Status 
                                   FROM ProductBatches WHERE BatchID = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", batchId.Value);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtBatchNumber.Text = reader["BatchNumber"].ToString();
                                dtpProductionDate.Value = Convert.ToDateTime(reader["ProductionDate"]);
                                txtProductType.Text = reader["ProductType"].ToString();
                                nudQuantity.Value = Convert.ToDecimal(reader["Quantity"]);
                                cmbStatus.SelectedItem = reader["Status"].ToString();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBatchNumber.Text))
            {
                MessageBox.Show("Введите номер партии!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtProductType.Text))
            {
                MessageBox.Show("Введите тип продукта!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query;

                    if (batchId.HasValue)
                    {
                        query = @"UPDATE ProductBatches 
                                SET BatchNumber = @number, ProductionDate = @date, 
                                    ProductType = @type, Quantity = @quantity, Status = @status
                                WHERE BatchID = @id";
                    }
                    else
                    {
                        query = @"INSERT INTO ProductBatches (BatchNumber, ProductionDate, ProductType, Quantity, Status)
                                VALUES (@number, @date, @type, @quantity, @status)";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@number", txtBatchNumber.Text.Trim());
                        cmd.Parameters.AddWithValue("@date", dtpProductionDate.Value);
                        cmd.Parameters.AddWithValue("@type", txtProductType.Text.Trim());
                        cmd.Parameters.AddWithValue("@quantity", nudQuantity.Value);
                        cmd.Parameters.AddWithValue("@status", cmbStatus.SelectedItem.ToString());

                        if (batchId.HasValue)
                        {
                            cmd.Parameters.AddWithValue("@id", batchId.Value);
                        }

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}