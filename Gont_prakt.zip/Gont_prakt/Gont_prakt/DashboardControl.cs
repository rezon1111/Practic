﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class DashboardControl : UserControl
    {
        private User currentUser;
        private Panel statsPanel;
        private Panel chartsPanel;
        private DataGridView dgvRecentBatches;
        private Label lblWelcome;
        private System.Windows.Forms.Timer refreshTimer;
        private Button btnRefresh;
        private Button btnExport;
        private ComboBox cmbPeriod;

        // Элементы для визуализации данных
        private Panel panelAnalysis;
        private Panel panelStatus;
        private Panel panelTrend;
        private ListBox lbAnalysis;
        private ListBox lbStatus;
        private ListBox lbTrend;

        public DashboardControl(User user)
        {
            InitializeComponent();
            currentUser = user;
            InitializeCustomComponents();
            LoadDashboard();

            // Автообновление каждые 30 секунд
            refreshTimer = new System.Windows.Forms.Timer();
            refreshTimer.Interval = 30000;
            refreshTimer.Tick += (s, e) => LoadDashboard();
            refreshTimer.Start();
        }

        private void InitializeCustomComponents()
        {
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Dock = DockStyle.Fill;
            this.AutoScroll = true;

            // Верхняя панель с приветствием и кнопками
            Panel topPanel = new Panel
            {
                Height = 80,
                Dock = DockStyle.Top,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            lblWelcome = new Label
            {
                Text = $"Добро пожаловать, {currentUser.FullName}!",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 73, 94),
                Location = new Point(20, 20),
                AutoSize = true
            };

            btnRefresh = new Button
            {
                Text = "Обновить",
                Location = new Point(600, 25),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnRefresh.Click += (s, e) => LoadDashboard();

            btnExport = new Button
            {
                Text = "Экспорт",
                Location = new Point(720, 25),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExport.Click += BtnExport_Click;

            cmbPeriod = new ComboBox
            {
                Location = new Point(480, 30),
                Size = new Size(100, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10)
            };
            cmbPeriod.Items.AddRange(new object[] { "Сегодня", "Неделя", "Месяц", "Год", "Все время" });
            cmbPeriod.SelectedIndex = 4; // "Все время" по умолчанию
            cmbPeriod.SelectedIndexChanged += (s, e) => LoadDashboard();

            topPanel.Controls.Add(lblWelcome);
            topPanel.Controls.Add(cmbPeriod);
            topPanel.Controls.Add(btnRefresh);
            topPanel.Controls.Add(btnExport);

            // Панель статистики (карточки)
            statsPanel = new Panel
            {
                Height = 150,
                Dock = DockStyle.Top,
                BackColor = Color.Transparent,
                Padding = new Padding(10)
            };

            // Панель визуализации данных
            chartsPanel = new Panel
            {
                Height = 300,
                Dock = DockStyle.Top,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            CreateVisualPanels();

            // Таблица последних партий
            Panel tablePanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            Label lblRecentTitle = new Label
            {
                Text = "Последние партии",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.FromArgb(52, 73, 94),
                Location = new Point(10, 10),
                AutoSize = true
            };

            dgvRecentBatches = new DataGridView
            {
                Location = new Point(10, 40),
                Size = new Size(this.Width - 40, 200),
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            // Стили для DataGridView
            dgvRecentBatches.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgvRecentBatches.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvRecentBatches.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 73, 94);
            dgvRecentBatches.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvRecentBatches.EnableHeadersVisualStyles = false;

            tablePanel.Controls.Add(lblRecentTitle);
            tablePanel.Controls.Add(dgvRecentBatches);

            this.Controls.Add(tablePanel);
            this.Controls.Add(chartsPanel);
            this.Controls.Add(statsPanel);
            this.Controls.Add(topPanel);
        }

        private void CreateVisualPanels()
        {
            // Панель 1: Анализы (столбчатая диаграмма в виде прогресс-баров)
            panelAnalysis = new Panel
            {
                Location = new Point(10, 10),
                Size = new Size(250, 280),
                BackColor = Color.FromArgb(250, 250, 250),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblAnalysisTitle = new Label
            {
                Text = "Средние значения параметров",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.FromArgb(52, 73, 94)
            };

            lbAnalysis = new ListBox
            {
                Location = new Point(10, 35),
                Size = new Size(230, 240),
                BorderStyle = BorderStyle.None,
                BackColor = Color.FromArgb(250, 250, 250),
                Font = new Font("Segoe UI", 9),
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = 25
            };
            lbAnalysis.DrawItem += LbAnalysis_DrawItem;

            panelAnalysis.Controls.Add(lblAnalysisTitle);
            panelAnalysis.Controls.Add(lbAnalysis);

            // Панель 2: Статусы партий (круговая диаграмма в виде цветных полос)
            panelStatus = new Panel
            {
                Location = new Point(270, 10),
                Size = new Size(250, 280),
                BackColor = Color.FromArgb(250, 250, 250),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblStatusTitle = new Label
            {
                Text = "Статусы партий",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.FromArgb(52, 73, 94)
            };

            lbStatus = new ListBox
            {
                Location = new Point(10, 35),
                Size = new Size(230, 240),
                BorderStyle = BorderStyle.None,
                BackColor = Color.FromArgb(250, 250, 250),
                Font = new Font("Segoe UI", 9),
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = 30
            };
            lbStatus.DrawItem += LbStatus_DrawItem;

            panelStatus.Controls.Add(lblStatusTitle);
            panelStatus.Controls.Add(lbStatus);

            // Панель 3: Тренд анализов (линейный график в виде списка)
            panelTrend = new Panel
            {
                Location = new Point(530, 10),
                Size = new Size(250, 280),
                BackColor = Color.FromArgb(250, 250, 250),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblTrendTitle = new Label
            {
                Text = "Активность по дням",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true,
                ForeColor = Color.FromArgb(52, 73, 94)
            };

            lbTrend = new ListBox
            {
                Location = new Point(10, 35),
                Size = new Size(230, 240),
                BorderStyle = BorderStyle.None,
                BackColor = Color.FromArgb(250, 250, 250),
                Font = new Font("Segoe UI", 9),
                DrawMode = DrawMode.OwnerDrawVariable,
                ItemHeight = 20
            };
            lbTrend.DrawItem += LbTrend_DrawItem;

            panelTrend.Controls.Add(lblTrendTitle);
            panelTrend.Controls.Add(lbTrend);

            chartsPanel.Controls.Add(panelAnalysis);
            chartsPanel.Controls.Add(panelStatus);
            chartsPanel.Controls.Add(panelTrend);
        }

        // Метод для получения диапазона дат на основе выбранного периода
        private (DateTime startDate, DateTime endDate) GetDateRange()
        {
            DateTime endDate = DateTime.Now;
            DateTime startDate;

            switch (cmbPeriod.SelectedItem.ToString())
            {
                case "Сегодня":
                    startDate = DateTime.Today;
                    break;
                case "Неделя":
                    startDate = DateTime.Today.AddDays(-7);
                    break;
                case "Месяц":
                    startDate = DateTime.Today.AddMonths(-1);
                    break;
                case "Год":
                    startDate = DateTime.Today.AddYears(-1);
                    break;
                case "Все время":
                default:
                    startDate = new DateTime(2000, 1, 1); // Очень старая дата
                    break;
            }

            return (startDate, endDate);
        }

        private void LbAnalysis_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            ListBox lb = sender as ListBox;
            e.DrawBackground();

            if (lb.Items[e.Index] is AnalysisItem item)
            {
                // Рисуем название параметра
                using (Brush textBrush = new SolidBrush(e.ForeColor))
                {
                    e.Graphics.DrawString(item.ParameterName, e.Font, textBrush, e.Bounds.X + 5, e.Bounds.Y + 5);
                }

                // Рисуем прогресс-бар
                int barWidth = (int)((item.Value / 20) * 150); // Максимум 20 для шкалы
                if (barWidth > 150) barWidth = 150;

                Rectangle barRect = new Rectangle(e.Bounds.X + 120, e.Bounds.Y + 7, barWidth, 15);

                using (Brush barBrush = new SolidBrush(item.Color))
                {
                    e.Graphics.FillRectangle(barBrush, barRect);
                }

                // Рисуем значение
                using (Brush valueBrush = new SolidBrush(Color.Black))
                {
                    e.Graphics.DrawString(item.Value.ToString("F1"), e.Font, valueBrush,
                        e.Bounds.X + 180, e.Bounds.Y + 5);
                }
            }

            e.DrawFocusRectangle();
        }

        private void LbStatus_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            ListBox lb = sender as ListBox;
            e.DrawBackground();

            if (lb.Items[e.Index] is StatusItem item)
            {
                // Цветной квадрат
                Rectangle colorRect = new Rectangle(e.Bounds.X + 5, e.Bounds.Y + 5, 20, 20);
                using (Brush colorBrush = new SolidBrush(item.Color))
                {
                    e.Graphics.FillRectangle(colorBrush, colorRect);
                }

                // Название статуса
                using (Brush textBrush = new SolidBrush(e.ForeColor))
                {
                    e.Graphics.DrawString(item.Status, e.Font, textBrush, e.Bounds.X + 30, e.Bounds.Y + 8);
                }

                // Количество и процент
                string valueText = $"{item.Count} ({item.Percent}%)";
                using (Brush valueBrush = new SolidBrush(Color.Gray))
                {
                    e.Graphics.DrawString(valueText, e.Font, valueBrush, e.Bounds.X + 150, e.Bounds.Y + 8);
                }
            }

            e.DrawFocusRectangle();
        }

        private void LbTrend_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            ListBox lb = sender as ListBox;
            e.DrawBackground();

            if (lb.Items[e.Index] is TrendItem item)
            {
                // Дата
                using (Brush textBrush = new SolidBrush(e.ForeColor))
                {
                    e.Graphics.DrawString(item.Date, e.Font, textBrush, e.Bounds.X + 5, e.Bounds.Y + 2);
                }

                // Количество анализов
                string countText = $"{item.Count} анализов";
                using (Brush countBrush = new SolidBrush(Color.FromArgb(46, 204, 113)))
                {
                    e.Graphics.DrawString(countText, e.Font, countBrush, e.Bounds.X + 100, e.Bounds.Y + 2);
                }

                // Рисуем линию тренда (маленький график)
                if (e.Index > 0 && lb.Items[e.Index - 1] is TrendItem prevItem)
                {
                    using (Pen pen = new Pen(Color.FromArgb(52, 152, 219), 2))
                    {
                        int x1 = e.Bounds.X + 180;
                        int y1 = e.Bounds.Y + 10 - (prevItem.Count * 2);
                        int x2 = e.Bounds.X + 210;
                        int y2 = e.Bounds.Y + 10 - (item.Count * 2);
                        e.Graphics.DrawLine(pen, x1, y1, x2, y2);
                    }
                }
            }

            e.DrawFocusRectangle();
        }

        private void LoadDashboard()
        {
            try
            {
                var (startDate, endDate) = GetDateRange();
                var stats = DatabaseHelper.GetDashboardStatistics(startDate, endDate);

                statsPanel.Controls.Clear();
                CreateStatCards(stats);

                UpdateVisualData(startDate, endDate);

                if (stats.ContainsKey("RecentBatches") && stats["RecentBatches"] != null)
                {
                    dgvRecentBatches.DataSource = stats["RecentBatches"] as DataTable;
                }

                // Принудительно обновляем отрисовку ListBox
                lbAnalysis.Refresh();
                lbStatus.Refresh();
                lbTrend.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки дашборда: {ex.Message}");
            }
        }

        private void UpdateVisualData(DateTime startDate, DateTime endDate)
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    // 1. Данные для анализов с учетом периода
                    string analysisQuery = @"
                        SELECT TOP 5 
                            qp.ParameterName,
                            AVG(ar.ResultValue) as AvgValue
                        FROM AnalysisResults ar
                        JOIN QualityParameters qp ON ar.ParameterID = qp.ParameterID
                        WHERE ar.AnalysisDate BETWEEN @startDate AND @endDate
                        GROUP BY qp.ParameterName
                        ORDER BY AvgValue DESC";

                    lbAnalysis.Items.Clear();
                    using (SqlCommand cmd = new SqlCommand(analysisQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lbAnalysis.Items.Add(new AnalysisItem
                                {
                                    ParameterName = reader["ParameterName"].ToString(),
                                    Value = Convert.ToDouble(reader["AvgValue"]),
                                    Color = GetColorForParameter(reader["ParameterName"].ToString())
                                });
                            }
                        }
                    }

                    // 2. Данные для статусов - процент от общего числа партий (не зависит от даты)
                    string statusQuery = @"
                        SELECT 
                            Status,
                            COUNT(*) as Count,
                            COUNT(*) * 100.0 / (SELECT COUNT(*) FROM ProductBatches) as [Percent]
                        FROM ProductBatches
                        GROUP BY Status";

                    lbStatus.Items.Clear();
                    using (SqlCommand cmd = new SqlCommand(statusQuery, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string status = reader["Status"].ToString();
                                lbStatus.Items.Add(new StatusItem
                                {
                                    Status = status,
                                    Count = Convert.ToInt32(reader["Count"]),
                                    Percent = Convert.ToInt32(reader["Percent"]),
                                    Color = GetColorForStatus(status)
                                });
                            }
                        }
                    }

                    // 3. Данные для тренда с учетом периода
                    string trendQuery = @"
                        SELECT TOP 7
                            CAST(AnalysisDate AS DATE) as Date,
                            COUNT(*) as Count
                        FROM AnalysisResults
                        WHERE AnalysisDate BETWEEN @startDate AND @endDate
                        GROUP BY CAST(AnalysisDate AS DATE)
                        ORDER BY Date DESC";

                    lbTrend.Items.Clear();
                    using (SqlCommand cmd = new SqlCommand(trendQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@startDate", startDate);
                        cmd.Parameters.AddWithValue("@endDate", endDate);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lbTrend.Items.Add(new TrendItem
                                {
                                    Date = Convert.ToDateTime(reader["Date"]).ToString("dd.MM"),
                                    Count = Convert.ToInt32(reader["Count"])
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private Color GetColorForParameter(string param)
        {
            switch (param)
            {
                case "Влага": return Color.FromArgb(52, 152, 219);
                case "Зольность": return Color.FromArgb(155, 89, 182);
                case "Сера": return Color.FromArgb(241, 196, 15);
                case "Летучие вещества": return Color.FromArgb(230, 126, 34);
                case "Прочность": return Color.FromArgb(46, 204, 113);
                default: return Color.FromArgb(52, 73, 94);
            }
        }

        private Color GetColorForStatus(string status)
        {
            switch (status)
            {
                case "Approved": return Color.FromArgb(46, 204, 113);
                case "Pending": return Color.FromArgb(241, 196, 15);
                case "Rejected": return Color.FromArgb(231, 76, 60);
                default: return Color.FromArgb(52, 152, 219);
            }
        }

        private void CreateStatCards(Dictionary<string, object> stats)
        {
            int x = 10;
            var cardData = new[]
            {
                new { Title = "Всего партий", Value = stats["TotalBatches"].ToString(), Color = Color.FromArgb(52, 152, 219) },
                new { Title = "Всего анализов", Value = stats["TotalAnalysis"].ToString(), Color = Color.FromArgb(46, 204, 113) },
                new { Title = "Прохождение", Value = $"{Convert.ToDecimal(stats["PassRate"]):F1}%", Color = Color.FromArgb(155, 89, 182) },
                new { Title = "Активных пользователей", Value = stats["ActiveUsers"].ToString(), Color = Color.FromArgb(241, 196, 15) }
            };

            foreach (var data in cardData)
            {
                Panel card = CreateStatCard(data.Title, data.Value, data.Color);
                card.Location = new Point(x, 10);
                statsPanel.Controls.Add(card);
                x += card.Width + 10;
            }
        }

        private Panel CreateStatCard(string title, string value, Color color)
        {
            Panel card = new Panel
            {
                Width = 180,
                Height = 120,
                BackColor = color,
                Margin = new Padding(5)
            };

            // Скругленные углы
            card.Paint += (s, e) =>
            {
                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddArc(0, 0, 20, 20, 180, 90);
                path.AddArc(card.Width - 20, 0, 20, 20, 270, 90);
                path.AddArc(card.Width - 20, card.Height - 20, 20, 20, 0, 90);
                path.AddArc(0, card.Height - 20, 20, 20, 90, 90);
                card.Region = new Region(path);
            };

            Label lblTitle = new Label
            {
                Text = title,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 15),
                AutoSize = true
            };

            Label lblValue = new Label
            {
                Text = value,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                Location = new Point(10, 50),
                AutoSize = true
            };

            card.Controls.Add(lblTitle);
            card.Controls.Add(lblValue);

            return card;
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                DefaultExt = "csv",
                FileName = $"Dashboard_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                DatabaseHelper.ExportToCSV(dgvRecentBatches, saveDialog.FileName);
            }
        }

        // Вспомогательные классы для хранения данных
        private class AnalysisItem
        {
            public string ParameterName { get; set; }
            public double Value { get; set; }
            public Color Color { get; set; }
        }

        private class StatusItem
        {
            public string Status { get; set; }
            public int Count { get; set; }
            public int Percent { get; set; }
            public Color Color { get; set; }
        }

        private class TrendItem
        {
            public string Date { get; set; }
            public int Count { get; set; }
        }
    }
}