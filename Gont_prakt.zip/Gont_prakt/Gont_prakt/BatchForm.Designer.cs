﻿namespace Gont_prakt
{
    partial class BatchForm
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtBatchNumber;
        private DateTimePicker dtpProductionDate;
        private TextBox txtProductType;
        private NumericUpDown nudQuantity;
        private ComboBox cmbStatus;
        private Button btnSave;
        private Button btnCancel;
        private Label lblBatchNumber;
        private Label lblProductionDate;
        private Label lblProductType;
        private Label lblQuantity;
        private Label lblStatus;
        private Panel panelMain;
        private Panel panelButtons;
        private Label lblTitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtBatchNumber = new TextBox();
            this.dtpProductionDate = new DateTimePicker();
            this.txtProductType = new TextBox();
            this.nudQuantity = new NumericUpDown();
            this.cmbStatus = new ComboBox();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.lblBatchNumber = new Label();
            this.lblProductionDate = new Label();
            this.lblProductType = new Label();
            this.lblQuantity = new Label();
            this.lblStatus = new Label();
            this.panelMain = new Panel();
            this.panelButtons = new Panel();
            this.lblTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            this.panelMain.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.SuspendLayout();

            // Form settings
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(236, 240, 241);
            this.ClientSize = new System.Drawing.Size(500, 550);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BatchForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Партия продукции";

            // panelMain
            this.panelMain.BackColor = System.Drawing.Color.White;
            this.panelMain.BorderStyle = BorderStyle.None;
            this.panelMain.Controls.Add(this.lblTitle);
            this.panelMain.Controls.Add(this.lblBatchNumber);
            this.panelMain.Controls.Add(this.txtBatchNumber);
            this.panelMain.Controls.Add(this.lblProductionDate);
            this.panelMain.Controls.Add(this.dtpProductionDate);
            this.panelMain.Controls.Add(this.lblProductType);
            this.panelMain.Controls.Add(this.txtProductType);
            this.panelMain.Controls.Add(this.lblQuantity);
            this.panelMain.Controls.Add(this.nudQuantity);
            this.panelMain.Controls.Add(this.lblStatus);
            this.panelMain.Controls.Add(this.cmbStatus);
            this.panelMain.Controls.Add(this.panelButtons);
            this.panelMain.Location = new System.Drawing.Point(20, 20);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(460, 510);
            this.panelMain.TabIndex = 0;
            this.panelMain.Padding = new Padding(20);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblTitle.Location = new System.Drawing.Point(140, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(180, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Партия продукции";

            // lblBatchNumber
            this.lblBatchNumber.AutoSize = true;
            this.lblBatchNumber.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblBatchNumber.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblBatchNumber.Location = new System.Drawing.Point(40, 70);
            this.lblBatchNumber.Name = "lblBatchNumber";
            this.lblBatchNumber.Size = new System.Drawing.Size(106, 19);
            this.lblBatchNumber.TabIndex = 1;
            this.lblBatchNumber.Text = "Номер партии:";

            // txtBatchNumber
            this.txtBatchNumber.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtBatchNumber.Location = new System.Drawing.Point(40, 95);
            this.txtBatchNumber.Name = "txtBatchNumber";
            this.txtBatchNumber.Size = new System.Drawing.Size(380, 27);
            this.txtBatchNumber.TabIndex = 2;
            this.txtBatchNumber.BorderStyle = BorderStyle.FixedSingle;
            this.txtBatchNumber.BackColor = System.Drawing.Color.FromArgb(249, 249, 249);

            // lblProductionDate
            this.lblProductionDate.AutoSize = true;
            this.lblProductionDate.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProductionDate.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblProductionDate.Location = new System.Drawing.Point(40, 135);
            this.lblProductionDate.Name = "lblProductionDate";
            this.lblProductionDate.Size = new System.Drawing.Size(124, 19);
            this.lblProductionDate.TabIndex = 3;
            this.lblProductionDate.Text = "Дата производства:";

            // dtpProductionDate
            this.dtpProductionDate.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.dtpProductionDate.Location = new System.Drawing.Point(40, 160);
            this.dtpProductionDate.Name = "dtpProductionDate";
            this.dtpProductionDate.Size = new System.Drawing.Size(380, 27);
            this.dtpProductionDate.TabIndex = 4;
            this.dtpProductionDate.Format = DateTimePickerFormat.Short;

            // lblProductType
            this.lblProductType.AutoSize = true;
            this.lblProductType.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProductType.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblProductType.Location = new System.Drawing.Point(40, 200);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(98, 19);
            this.lblProductType.TabIndex = 5;
            this.lblProductType.Text = "Тип продукта:";

            // txtProductType
            this.txtProductType.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtProductType.Location = new System.Drawing.Point(40, 225);
            this.txtProductType.Name = "txtProductType";
            this.txtProductType.Size = new System.Drawing.Size(380, 27);
            this.txtProductType.TabIndex = 6;
            this.txtProductType.BorderStyle = BorderStyle.FixedSingle;
            this.txtProductType.BackColor = System.Drawing.Color.FromArgb(249, 249, 249);

            // lblQuantity
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblQuantity.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblQuantity.Location = new System.Drawing.Point(40, 265);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(87, 19);
            this.lblQuantity.TabIndex = 7;
            this.lblQuantity.Text = "Количество:";

            // nudQuantity
            this.nudQuantity.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.nudQuantity.Location = new System.Drawing.Point(40, 290);
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(380, 27);
            this.nudQuantity.TabIndex = 8;
            this.nudQuantity.DecimalPlaces = 2;
            this.nudQuantity.Maximum = 1000000;
            this.nudQuantity.ThousandsSeparator = true;

            // lblStatus
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.lblStatus.Location = new System.Drawing.Point(40, 330);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(56, 19);
            this.lblStatus.TabIndex = 9;
            this.lblStatus.Text = "Статус:";

            // cmbStatus
            this.cmbStatus.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cmbStatus.Location = new System.Drawing.Point(40, 355);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(380, 28);
            this.cmbStatus.TabIndex = 10;
            this.cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbStatus.BackColor = System.Drawing.Color.FromArgb(249, 249, 249);
            this.cmbStatus.Items.AddRange(new object[] { "Pending", "Approved", "Rejected" });

            // panelButtons
            this.panelButtons.BackColor = System.Drawing.Color.FromArgb(236, 240, 241);
            this.panelButtons.Controls.Add(this.btnSave);
            this.panelButtons.Controls.Add(this.btnCancel);
            this.panelButtons.Location = new System.Drawing.Point(30, 410);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(400, 70);
            this.panelButtons.TabIndex = 11;

            // btnSave
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(46, 204, 113);
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(100, 15);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 40);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new EventHandler(this.BtnSave_Click);

            // btnCancel
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(149, 165, 166);
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(220, 15);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 40);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);

            // BatchForm
            this.Controls.Add(this.panelMain);
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.panelButtons.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}