﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Gont_prakt
{
    public partial class UserManagementForm : Form
    {
        public UserManagementForm()
        {
            InitializeComponent();
            LoadUsers();

            // Подписываемся на события
            this.txtSearch.TextChanged += TxtSearch_TextChanged;
            this.cmbRole.SelectedIndexChanged += (s, e) => FilterData();
            this.btnRefresh.Click += (s, e) => LoadUsers();
            this.btnAdd.Click += BtnAdd_Click;
            this.btnEdit.Click += BtnEdit_Click;
            this.btnDelete.Click += BtnDelete_Click;
            this.btnToggleActive.Click += BtnToggleActive_Click;
            this.btnExport.Click += BtnExport_Click;
            this.dgvUsers.CellFormatting += DgvUsers_CellFormatting;
        }

        private void LoadUsers()
        {
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT 
                        UserID,
                        Username AS 'Логин',
                        FullName AS 'ФИО',
                        Email AS 'Email',
                        Role AS 'Роль',
                        CreatedDate AS 'Дата регистрации',
                        CASE WHEN IsActive = 1 THEN 'Активен' ELSE 'Заблокирован' END AS 'Статус'
                    FROM Users";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvUsers.DataSource = dt;

                        if (dgvUsers.Columns["UserID"] != null)
                            dgvUsers.Columns["UserID"].Visible = false;

                        lblTotalUsers.Text = $"Всего: {dt.Rows.Count}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки пользователей: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FilterData()
        {
            if (dgvUsers.DataSource is DataTable dt)
            {
                string filter = "";

                if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    filter = $"CONVERT([Логин], 'System.String') LIKE '%{txtSearch.Text}%' OR " +
                            $"CONVERT([ФИО], 'System.String') LIKE '%{txtSearch.Text}%' OR " +
                            $"CONVERT([Email], 'System.String') LIKE '%{txtSearch.Text}%'";
                }

                if (cmbRole.SelectedItem != null && cmbRole.SelectedItem.ToString() != "Все")
                {
                    if (!string.IsNullOrEmpty(filter))
                        filter += " AND ";
                    filter += $"[Роль] = '{cmbRole.SelectedItem}'";
                }

                dt.DefaultView.RowFilter = filter;
                lblTotalUsers.Text = $"Всего: {dt.DefaultView.Count}";
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            FilterData();
        }

        private void DgvUsers_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvUsers.Columns[e.ColumnIndex].Name == "Статус" && e.Value != null)
            {
                string status = e.Value.ToString();
                if (status == "Активен")
                    e.CellStyle.ForeColor = Color.Green;
                else
                    e.CellStyle.ForeColor = Color.Red;
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            UserEditForm form = new UserEditForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadUsers();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для редактирования!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);
            UserEditForm form = new UserEditForm(userId);
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadUsers();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для удаления!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string username = dgvUsers.SelectedRows[0].Cells["Логин"].Value.ToString();

            if (username == "admin")
            {
                MessageBox.Show("Нельзя удалить администратора системы!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Вы уверены, что хотите удалить пользователя {username}?",
                "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);

                    using (SqlConnection conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();

                        string deleteAnalysis = "DELETE FROM AnalysisResults WHERE AnalyzedBy = @id";
                        using (SqlCommand cmd = new SqlCommand(deleteAnalysis, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", userId);
                            cmd.ExecuteNonQuery();
                        }

                        string deleteUser = "DELETE FROM Users WHERE UserID = @id";
                        using (SqlCommand cmd = new SqlCommand(deleteUser, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", userId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadUsers();
                    MessageBox.Show("Пользователь успешно удален!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnToggleActive_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя!", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string username = dgvUsers.SelectedRows[0].Cells["Логин"].Value.ToString();
            string currentStatus = dgvUsers.SelectedRows[0].Cells["Статус"].Value.ToString();
            bool isActive = currentStatus == "Активен";
            string action = isActive ? "заблокировать" : "активировать";

            if (username == "admin" && isActive)
            {
                MessageBox.Show("Нельзя заблокировать администратора системы!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Вы уверены, что хотите {action} пользователя {username}?",
                "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserID"].Value);

                    using (SqlConnection conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "UPDATE Users SET IsActive = @status WHERE UserID = @id";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@status", !isActive);
                            cmd.Parameters.AddWithValue("@id", userId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadUsers();
                    MessageBox.Show($"Пользователь успешно {action}!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                DefaultExt = "csv",
                FileName = $"Users_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                ExportToCSV(dgvUsers, saveDialog.FileName);
            }
        }

        private void ExportToCSV(DataGridView dgv, string filePath)
        {
            try
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(filePath, false, System.Text.Encoding.UTF8))
                {
                    for (int i = 0; i < dgv.Columns.Count; i++)
                    {
                        if (dgv.Columns[i].HeaderText != "UserID")
                        {
                            sw.Write(dgv.Columns[i].HeaderText);
                            if (i < dgv.Columns.Count - 1) sw.Write(";");
                        }
                    }
                    sw.WriteLine();

                    foreach (DataGridViewRow row in dgv.Rows)
                    {
                        for (int i = 0; i < dgv.Columns.Count; i++)
                        {
                            if (dgv.Columns[i].HeaderText != "UserID" && row.Cells[i].Value != null)
                            {
                                string value = row.Cells[i].Value.ToString().Replace(";", ",");
                                sw.Write(value);
                                if (i < dgv.Columns.Count - 1) sw.Write(";");
                            }
                        }
                        sw.WriteLine();
                    }
                }

                MessageBox.Show($"Данные экспортированы в {filePath}", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка экспорта: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}