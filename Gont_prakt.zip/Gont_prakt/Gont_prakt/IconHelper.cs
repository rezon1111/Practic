﻿// Добавьте в проект класс IconHelper.cs
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Gont_prakt
{
    public static class IconHelper
    {
        public static Image CreateStatusIcon(Color color, int size = 16)
        {
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (Brush brush = new SolidBrush(color))
                {
                    g.FillEllipse(brush, 2, 2, size - 4, size - 4);
                }
            }
            return bmp;
        }
    }
}